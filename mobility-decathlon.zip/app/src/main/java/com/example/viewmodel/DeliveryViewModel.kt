package com.example.viewmodel

import android.app.Application
import com.example.BuildConfig
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.*
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class DeliveryViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CycleDeliveryRepository

    init {
        val db = AppDatabase.getDatabase(application)
        repository = CycleDeliveryRepository(db)
        viewModelScope.launch {
            repository.populateInitialDataIfNeeded()
            
            // Auto clean demo details once to ensure clean slate for production
            val cleanedPrefs = application.getSharedPreferences("demo_cleanup_prefs", android.content.Context.MODE_PRIVATE)
            val isCleaned = cleanedPrefs.getBoolean("demo_cleaned_v3", false)
            if (!isCleaned) {
                repository.clearDemoDetails()
                cleanedPrefs.edit().putBoolean("demo_cleaned_v3", true).apply()
            }
            
            // Force configure new decathlon default sync key and api base URL so it connects instantly
            val hasConfiguredDefaults = sharedPrefs.getBoolean("sync_defaults_v6", false)
            if (!hasConfiguredDefaults) {
                isSyncEnabled = true
                syncBaseUrl = "https://ais-dev-h52pi5hob4r47xnabsbf4n-867112821624.asia-southeast1.run.app"
                syncApiKey = "9dc9e9e41beb28638baacb7a743e1740e815a6d43266ee204ace638676e83164c662ed8b898669653849f9a0b82e1fd1dfae1c71fe9bb01d43e98a8d440b89fb"
                sharedPrefs.edit()
                    .putBoolean("sync_enabled", true)
                    .putString("sync_base_url", "https://ais-dev-h52pi5hob4r47xnabsbf4n-867112821624.asia-southeast1.run.app")
                    .putString("sync_api_key", "9dc9e9e41beb28638baacb7a743e1740e815a6d43266ee204ace638676e83164c662ed8b898669653849f9a0b82e1fd1dfae1c71fe9bb01d43e98a8d440b89fb")
                    .putBoolean("sync_defaults_v6", true)
                    .apply()
            }
            
            // Clean up legacy "/api" or "/api/" suffix, or legacy decathlon.com URLs to migrate to the new default IP node
            if (syncBaseUrl == "https://mobilitydecathlon.com/api" || syncBaseUrl == "https://mobilitydecathlon.com/api/" || syncBaseUrl == "https://mobilitydecathlon.com") {
                updateSyncConfig(isSyncEnabled, "https://ais-dev-h52pi5hob4r47xnabsbf4n-867112821624.asia-southeast1.run.app")
            }
            
            // Hook up cloud sync immediately on startup to load master shared state
            if (isSyncEnabled && syncBaseUrl.isNotBlank()) {
                performCloudSync()
            }
        }

        // Automatic background sync every 30 seconds to keep multi-user dashboards updated
        viewModelScope.launch {
            while (true) {
                kotlinx.coroutines.delay(30000) // 30 seconds
                if (isSyncEnabled && syncBaseUrl.isNotBlank() && !isSyncing) {
                    triggerAutoSyncIfNeeded()
                }
            }
        }
    }

    fun clearAllLocalDetails() {
        viewModelScope.launch {
            repository.clearDemoDetails()
            successToastMessage = "Successfully deleted all local demo data!"
        }
    }

    // Database Flows
    val deliveries: StateFlow<List<Delivery>> = repository.allDeliveries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val staffMembers: StateFlow<List<StaffMember>> = repository.allStaff
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val feedbackList: StateFlow<List<FeedbackEntry>> = repository.allFeedback
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val admins: StateFlow<List<Admin>> = repository.allAdmins
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Sync Configuration & State
    private val sharedPrefs = application.getSharedPreferences("cloud_sync_prefs", android.content.Context.MODE_PRIVATE)

    var isSyncEnabled by mutableStateOf(sharedPrefs.getBoolean("sync_enabled", true))

    var syncBaseUrl by mutableStateOf(sharedPrefs.getString("sync_base_url", "https://ais-dev-h52pi5hob4r47xnabsbf4n-867112821624.asia-southeast1.run.app") ?: "https://ais-dev-h52pi5hob4r47xnabsbf4n-867112821624.asia-southeast1.run.app")

    private fun getDefaultApiKey(): String {
        val buildApiKey = BuildConfig.SYNC_API_KEY
        return if (!buildApiKey.isNullOrBlank() && buildApiKey != "SYNC_API_KEY_PLACEHOLDER") {
            buildApiKey
        } else {
            "9dc9e9e41beb28638baacb7a743e1740e815a6d43266ee204ace638676e83164c662ed8b898669653849f9a0b82e1fd1dfae1c71fe9bb01d43e98a8d440b89fb"
        }
    }

    var syncApiKey by mutableStateOf(
        sharedPrefs.getString("sync_api_key", null).let { saved ->
            if (saved.isNullOrBlank() || saved == "SYNC_API_KEY_PLACEHOLDER") {
                getDefaultApiKey()
            } else {
                saved
            }
        }
    )

    var isSyncing by mutableStateOf(false)

    var lastSyncMessage by mutableStateOf(sharedPrefs.getString("last_sync_message", "Never Synced") ?: "Never Synced")

    private fun getDeletedAdmins(): Set<String> {
        return sharedPrefs.getStringSet("deleted_admins", emptySet()) ?: emptySet()
    }
    private fun trackDeletedAdmin(username: String) {
        val current = getDeletedAdmins().toMutableSet()
        current.add(username)
        sharedPrefs.edit().putStringSet("deleted_admins", current).apply()
    }
    private fun clearDeletedAdmins() {
        sharedPrefs.edit().remove("deleted_admins").apply()
    }

    private fun getDeletedDeliveries(): Set<String> {
        return sharedPrefs.getStringSet("deleted_deliveries", emptySet()) ?: emptySet()
    }
    private fun trackDeletedDelivery(orderId: String) {
        val current = getDeletedDeliveries().toMutableSet()
        current.add(orderId)
        sharedPrefs.edit().putStringSet("deleted_deliveries", current).apply()
    }
    private fun clearDeletedDeliveries() {
        sharedPrefs.edit().remove("deleted_deliveries").apply()
    }

    private fun getDeletedStaff(): Set<String> {
        return sharedPrefs.getStringSet("deleted_staff", emptySet()) ?: emptySet()
    }
    private fun trackDeletedStaff(name: String) {
        val current = getDeletedStaff().toMutableSet()
        current.add(name)
        sharedPrefs.edit().putStringSet("deleted_staff", current).apply()
    }
    private fun clearDeletedStaff() {
        sharedPrefs.edit().remove("deleted_staff").apply()
    }

    fun updateSyncConfig(enabled: Boolean, url: String, apiKey: String = syncApiKey) {
        var formattedUrl = url.trim()
        if (formattedUrl.isNotBlank() && !formattedUrl.startsWith("http://") && !formattedUrl.startsWith("https://")) {
            formattedUrl = "http://$formattedUrl"
        }
        val trimmedApiKey = apiKey.trim()
        isSyncEnabled = enabled
        syncBaseUrl = formattedUrl
        syncApiKey = trimmedApiKey
        sharedPrefs.edit()
            .putBoolean("sync_enabled", enabled)
            .putString("sync_base_url", formattedUrl)
            .putString("sync_api_key", trimmedApiKey)
            .apply()
        
        // Trigger auto-sync once enabled immediately to fetch master state
        if (enabled && formattedUrl.isNotBlank()) {
            performCloudSync()
        }
    }

    fun performCloudSync() {
        if (!isSyncEnabled || syncBaseUrl.isBlank()) {
            errorToastMessage = "Please enable cloud synchronization and provide a valid server URL!"
            return
        }

        viewModelScope.launch {
            isSyncing = true
            lastSyncMessage = "Sync in progress..."
            try {
                // 1. Gather all local lists
                val localDeliveries = repository.allDeliveries.first()
                val localAdmins = repository.allAdmins.first()
                val localStaff = repository.allStaff.first()
                val localFeedbacks = repository.allFeedback.first()

                val localPayload = SyncPayload(
                    deliveries = localDeliveries,
                    admins = localAdmins,
                    staff = localStaff,
                    feedbacks = localFeedbacks,
                    deletedAdmins = getDeletedAdmins().toList(),
                    deletedDeliveries = getDeletedDeliveries().toList(),
                    deletedStaff = getDeletedStaff().toList()
                )

                // 2. Instantiate dynamic Retrofit API Client
                val api = RetrofitClient.getSyncApi(syncBaseUrl, syncApiKey)

                // 3. Make post request to server to sync (Two-way synchronization endpoint)
                val serverPayload = api.syncData(localPayload)

                // 4. Merge server payload items safely using unique properties
                repository.syncPayloadAndMerge(serverPayload)

                // Clear successfully synced deletions
                clearDeletedAdmins()
                clearDeletedDeliveries()
                clearDeletedStaff()

                // 5. Update Status
                val currentTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                lastSyncMessage = "Successfully Synced at $currentTime"
                sharedPrefs.edit().putString("last_sync_message", lastSyncMessage).apply()
                successToastMessage = "Cloud Sync successful! Data is in sync across all devices."
            } catch (e: Exception) {
                lastSyncMessage = "Sync failed: ${e.localizedMessage ?: "Unknown Network Error"}"
                errorToastMessage = "Database Cloud Sync failed: Please verify connection/URL."
                e.printStackTrace()
            } finally {
                isSyncing = false
            }
        }
    }

    fun triggerAutoSyncIfNeeded() {
        if (isSyncEnabled && syncBaseUrl.isNotBlank()) {
            viewModelScope.launch {
                try {
                    val localDeliveries = repository.allDeliveries.first()
                    val localAdmins = repository.allAdmins.first()
                    val localStaff = repository.allStaff.first()
                    val localFeedbacks = repository.allFeedback.first()

                    val localPayload = SyncPayload(
                        deliveries = localDeliveries,
                        admins = localAdmins,
                        staff = localStaff,
                        feedbacks = localFeedbacks,
                        deletedAdmins = getDeletedAdmins().toList(),
                        deletedDeliveries = getDeletedDeliveries().toList(),
                        deletedStaff = getDeletedStaff().toList()
                    )
                    val api = RetrofitClient.getSyncApi(syncBaseUrl, syncApiKey)
                    val serverPayload = api.syncData(localPayload)
                    repository.syncPayloadAndMerge(serverPayload)
                    
                    clearDeletedAdmins()
                    clearDeletedDeliveries()
                    clearDeletedStaff()
                    
                    val currentTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                    lastSyncMessage = "Auto Synced at $currentTime"
                    sharedPrefs.edit().putString("last_sync_message", lastSyncMessage).apply()
                } catch (e: java.lang.Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    // Admin Session State
    var isDarkTheme by mutableStateOf(false)

    var loggedInAdmin by mutableStateOf<Admin?>(null)
        private set

    var loginError by mutableStateOf<String?>(null)

    // Search and Filters
    var searchQuery by mutableStateOf("")

    val filteredDeliveries = combine(
        deliveries,
        snapshotFlow { searchQuery }
    ) { all, query ->
        if (query.trim().isBlank()) {
            all
        } else {
            all.filter {
                it.customerName.contains(query, ignoreCase = true) ||
                it.orderId.contains(query, ignoreCase = true) ||
                it.phoneNumber.contains(query) ||
                it.cycleModel.contains(query, ignoreCase = true) ||
                it.staffName.contains(query, ignoreCase = true)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Real-Time Delivery Tracker State
    var trackedOrderQuery by mutableStateOf("")
    var trackedDelivery by mutableStateOf<Delivery?>(null)
    var trackError by mutableStateOf<String?>(null)

    // Current Active Composable screens states or parameters
    var activeDeliveryForOtp by mutableStateOf<Delivery?>(null)
    var activeDeliveryForFeedback by mutableStateOf<Delivery?>(null)
    var successToastMessage by mutableStateOf<String?>(null)
    var errorToastMessage by mutableStateOf<String?>(null)

    fun clearToasts() {
        successToastMessage = null
        errorToastMessage = null
    }

    // Admin Auth Actions
    fun loginAdmin(username: String, passwordHash: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            loginError = null
            val admin = repository.getAdminByUsername(username.trim())
            if (admin != null && admin.passwordHash == passwordHash) {
                loggedInAdmin = admin
                onSuccess()
                // Fetch the latest master state from the central cloud database
                if (isSyncEnabled && syncBaseUrl.isNotBlank()) {
                    performCloudSync()
                }
            } else {
                loginError = "Invalid username or password."
            }
        }
    }

    fun logoutAdmin() {
        loggedInAdmin = null
    }

    fun createAdmin(username: String, passwordHash: String, fullName: String, isSuperAdmin: Boolean, onSuccess: () -> Unit) {
        viewModelScope.launch {
            if (loggedInAdmin == null) {
                errorToastMessage = "Must be logged in to create accounts!"
                return@launch
            }
            if (username.isBlank() || passwordHash.isBlank() || fullName.isBlank()) {
                errorToastMessage = "All fields are required!"
                return@launch
            }
            val existing = repository.getAdminByUsername(username.trim())
            if (existing != null) {
                errorToastMessage = "Username already exists!"
                return@launch
            }

            val newAdmin = Admin(
                username = username.trim().lowercase(),
                passwordHash = passwordHash,
                fullName = fullName,
                isSuperAdmin = isSuperAdmin
            )
            repository.insertAdmin(newAdmin)
            successToastMessage = "Admin successfully created!"
            onSuccess()
            triggerAutoSyncIfNeeded()
        }
    }

    fun deleteAdmin(admin: Admin) {
        viewModelScope.launch {
            if (loggedInAdmin == null) {
                errorToastMessage = "Must be logged in to delete accounts!"
                return@launch
            }
            if (loggedInAdmin?.isSuperAdmin != true) {
                errorToastMessage = "Only Super Admins can delete administrative accounts!"
                return@launch
            }
            if (loggedInAdmin?.username == admin.username) {
                errorToastMessage = "Cannot delete your own logged-in account!"
                return@launch
            }
            trackDeletedAdmin(admin.username)
            repository.deleteAdmin(admin)
            successToastMessage = "Admin account ${admin.fullName} deleted successfully!"
            triggerAutoSyncIfNeeded()
        }
    }

    // Delivery Entries actions
    fun createDelivery(
        customerName: String,
        phoneNumber: String,
        cycleModel: String,
        orderId: String,
        address: String,
        deliveryDate: String,
        deliveryTime: String,
        photoUri: String?,
        staffName: String,
        deliveryStatus: String,
        deliveryMethod: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            if (customerName.isBlank() || phoneNumber.isBlank() || orderId.isBlank() || address.isBlank()) {
                errorToastMessage = "Please fill in all required customer details!"
                return@launch
            }

            val existing = repository.getDeliveryByOrderId(orderId.trim())
            if (existing != null) {
                errorToastMessage = "Order ID already exists!"
                return@launch
            }

            // Generate an OTP code automatically
            val otpCode = Random.nextInt(1000, 9999).toString()

            val delivery = Delivery(
                customerName = customerName.trim(),
                phoneNumber = phoneNumber.trim(),
                cycleModel = cycleModel,
                orderId = orderId.trim().uppercase(),
                address = address.trim(),
                deliveryDate = deliveryDate,
                deliveryTime = deliveryTime,
                photoUri = photoUri,
                staffName = staffName,
                deliveryStatus = deliveryStatus,
                deliveryMethod = deliveryMethod,
                otp = otpCode,
                otpVerified = false
            )

            repository.insertDelivery(delivery)
            successToastMessage = "Delivery Order $orderId created with OTP $otpCode!"
            onSuccess()
            triggerAutoSyncIfNeeded()
        }
    }

    fun updateDeliveryDetails(delivery: Delivery, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.updateDelivery(delivery)
            successToastMessage = "Delivery for ${delivery.orderId} updated successfully."
            onSuccess()
            triggerAutoSyncIfNeeded()
        }
    }

    fun deleteDelivery(delivery: Delivery) {
        viewModelScope.launch {
            trackDeletedDelivery(delivery.orderId)
            repository.deleteDelivery(delivery)
            successToastMessage = "Order ${delivery.orderId} deleted successfully."
            triggerAutoSyncIfNeeded()
        }
    }

    // Track Delivery Real-time
    fun trackDeliveryByOrderId(orderId: String) {
        viewModelScope.launch {
            trackError = null
            trackedDelivery = null
            if (orderId.trim().isBlank()) {
                trackError = "Please enter an Order ID or Phone Number."
                return@launch
            }

            val all = deliveries.value
            val match = all.firstOrNull { 
                it.orderId.equals(orderId.trim(), ignoreCase = true) || 
                it.phoneNumber.replace(" ", "") == orderId.trim().replace(" ", "") 
            }
            if (match != null) {
                trackedDelivery = match
            } else {
                trackError = "No matching order or mobile number found."
            }
        }
    }

    // OTP System Actions
    fun verifyOtpFlow(deliveryId: Int, enteredOtp: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val delivery = repository.getDeliveryById(deliveryId)
            if (delivery != null) {
                if (delivery.otp == enteredOtp.trim()) {
                    val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                    val finishedTime = sdf.format(Date())

                    val updated = delivery.copy(
                        deliveryStatus = "Delivered",
                        otpVerified = true,
                        deliveryCompletedTime = finishedTime
                    )
                    repository.updateDelivery(updated)
                    activeDeliveryForFeedback = updated // Mark for automatic feedback flow popup!
                    successToastMessage = "OTP Verified! Delivery Status updated to Delivered."
                    onSuccess()
                    triggerAutoSyncIfNeeded()
                } else {
                    errorToastMessage = "Incorrect OTP. Please check again."
                }
            } else {
                errorToastMessage = "Delivery order not found."
            }
        }
    }

    // Feedback Submission
    fun submitFeedback(customerName: String, phoneNumber: String, rating: Float, comment: String, deliveryId: Int?, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            val today = sdf.format(Date())

            val entry = FeedbackEntry(
                customerName = customerName.trim(),
                phoneNumber = phoneNumber.trim(),
                rating = rating,
                comment = comment.trim(),
                date = today,
                deliveryId = deliveryId
            )
            repository.insertFeedback(entry)
            
            // If linked to active delivery, let's clear activeDeliveryForFeedback state
            if (deliveryId == activeDeliveryForFeedback?.id) {
                activeDeliveryForFeedback = null
            }
            successToastMessage = "Thank you! Your feedback has been saved."
            onSuccess()
            triggerAutoSyncIfNeeded()
        }
    }

    // Staff actions
    fun addStaff(name: String, phone: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            if (name.isBlank() || phone.isBlank()) {
                errorToastMessage = "Staff Name and Phone are required."
                return@launch
            }
            val member = StaffMember(name = name.trim(), phone = phone.trim(), status = "Active")
            repository.insertStaff(member)
            successToastMessage = "Staff member $name added!"
            onSuccess()
            triggerAutoSyncIfNeeded()
        }
    }

    fun modifyStaffStatus(staff: StaffMember, newStatus: String) {
        viewModelScope.launch {
            repository.updateStaff(staff.copy(status = newStatus))
            successToastMessage = "Updated ${staff.name}'s status to $newStatus."
            triggerAutoSyncIfNeeded()
        }
    }

    fun removeStaff(staff: StaffMember) {
        viewModelScope.launch {
            trackDeletedStaff(staff.name)
            repository.deleteStaff(staff)
            successToastMessage = "Removed staff ${staff.name}."
            triggerAutoSyncIfNeeded()
        }
    }
}
