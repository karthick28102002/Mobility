package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = DecathlonBlue,
    onPrimary = Color.White,
    secondary = DecathlonActiveOrange,
    onSecondary = Color.Black,
    background = DecathlonDarkText,
    onBackground = Color.White,
    surface = Color(0xFF1E2E3E),
    onSurface = Color.White,
    outline = DecathlonLightGrey
)

private val LightColorScheme = lightColorScheme(
    primary = DecathlonBlue,
    onPrimary = Color.White,
    secondary = DecathlonActiveOrange,
    onSecondary = Color.White,
    background = DecathlonLightBg,
    onBackground = DecathlonDarkText,
    surface = DecathlonCardWhite,
    onSurface = DecathlonDarkText,
    outline = DecathlonLightGrey,
    surfaceVariant = DecathlonLightBg,
    onSurfaceVariant = DecathlonDarkText
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Keep dynamicColor false to enforce Decathlon Blue corporate identity
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
