package com.example.ui

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.local.Delivery
import com.example.data.local.FeedbackEntry
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReportExporter {

    fun exportToPdf(context: Context, deliveries: List<Delivery>, feedbacks: List<FeedbackEntry>): File? {
        try {
            val pdfDocument = PdfDocument()
            val totalItems = deliveries.size
            val itemsPerPage = 12
            val totalPages = Math.max(1, (totalItems + itemsPerPage - 1) / itemsPerPage)

            val paint = Paint()
            val textPaint = Paint().apply {
                color = Color.BLACK
                textSize = 9f
                isAntiAlias = true
            }
            val titlePaint = Paint().apply {
                color = Color.BLACK
                textSize = 14f
                isFakeBoldText = true
                isAntiAlias = true
            }
            val headerPaint = Paint().apply {
                color = Color.BLACK
                textSize = 8.5f
                isFakeBoldText = true
                isAntiAlias = true
            }

            for (pageNumber in 0 until totalPages) {
                // A4 dimensions at 72 DPI are 595 x 842 points
                val pageInfo = PdfDocument.PageInfo.Builder(595, 842, pageNumber + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas: Canvas = page.canvas

                // Background / Margins
                paint.color = Color.WHITE
                canvas.drawRect(0f, 0f, 595f, 842f, paint)

                var y = 40f

                // Header Branding Border
                paint.color = Color.parseColor("#007ABD") // Decathlon blue
                canvas.drawRect(20f, y, 575f, y + 4f, paint)
                y += 20f

                // Document Header (Page 1 only)
                if (pageNumber == 0) {
                    canvas.drawText("DECATHLON CYCLEDELIVERY PRO - MANAGEMENT AUDIT", 20f, y, titlePaint)
                    y += 15f
                    paint.color = Color.DKGRAY
                    canvas.drawText("Marina Mall Center, Chennai  |  Report Generated: " + SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()), 20f, y, textPaint)
                    y += 25f

                    // Stats row
                    paint.color = Color.parseColor("#F8FAFC")
                    canvas.drawRect(20f, y, 575f, y + 45f, paint)
                    paint.color = Color.DKGRAY
                    val avgRating = if (feedbacks.isNotEmpty()) feedbacks.map { it.rating }.average() else 4.8
                    canvas.drawText("Total Recorded Deliveries: ${deliveries.size}", 30f, y + 18f, textPaint)
                    canvas.drawText("Completed Deliveries: ${deliveries.count { it.deliveryStatus == "Delivered" }}", 30f, y + 33f, textPaint)
                    canvas.drawText("Pending In-Transit: ${deliveries.count { it.deliveryStatus != "Delivered" }}", 280f, y + 18f, textPaint)
                    canvas.drawText("Avg Customer Rating: ${String.format(Locale.US, "%.2f", avgRating)} / 5 ★", 280f, y + 33f, textPaint)
                    y += 65f
                } else {
                    canvas.drawText("DECATHLON CYCLEDELIVERY PRO (Page ${pageNumber + 1} of $totalPages)", 20f, y, titlePaint)
                    y += 30f
                }

                // Table Header
                paint.color = Color.parseColor("#007ABD")
                canvas.drawRect(20f, y, 575f, y + 18f, paint)
                paint.color = Color.WHITE
                canvas.drawText("S.No", 25f, y + 12f, headerPaint)
                canvas.drawText("Order ID", 55f, y + 12f, headerPaint)
                canvas.drawText("Customer Name", 125f, y + 12f, headerPaint)
                canvas.drawText("Cycle Model", 240f, y + 12f, headerPaint)
                canvas.drawText("Status", 380f, y + 12f, headerPaint)
                canvas.drawText("Driver / Delivery Staff", 475f, y + 12f, headerPaint)

                y += 18f

                val startIndex = pageNumber * itemsPerPage
                val endIndex = Math.min(startIndex + itemsPerPage, totalItems)

                paint.color = Color.BLACK
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 0.5f

                for (i in startIndex until endIndex) {
                    val d = deliveries[i]
                    val drawY = y + 15f

                    // Draw entry borders
                    canvas.drawLine(20f, y + 22f, 575f, y + 22f, paint)

                    paint.style = Paint.Style.FILL
                    paint.color = Color.BLACK
                    canvas.drawText("${i + 1}", 25f, drawY, textPaint)
                    canvas.drawText(d.orderId, 55f, drawY, textPaint)

                    // Truncate customer name if too long
                    val custName = if (d.customerName.length > 20) d.customerName.take(18) + ".." else d.customerName
                    canvas.drawText(custName, 125f, drawY, textPaint)

                    // Truncate model name if too long
                    val modelName = if (d.cycleModel.length > 22) d.cycleModel.take(20) + ".." else d.cycleModel
                    canvas.drawText(modelName, 240f, drawY, textPaint)

                    canvas.drawText(d.deliveryStatus, 380f, drawY, textPaint)

                    val driver = if (d.staffName.isBlank()) "Unassigned" else d.staffName
                    canvas.drawText(driver, 475f, drawY, textPaint)

                    paint.style = Paint.Style.STROKE
                    y += 22f
                }

                // Page Footer
                paint.style = Paint.Style.FILL
                paint.color = Color.GRAY
                paint.textSize = 8f
                canvas.drawText("Decathlon Internal Delivery System - Strictly Confidential", 20f, 820f, paint)
                canvas.drawText("Generated using Decathlon CycleDelivery Pro • Page ${pageNumber + 1} of $totalPages", 380f, 820f, paint)

                pdfDocument.finishPage(page)
            }

            val dir = context.getExternalFilesDir("documents") ?: context.filesDir
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, "Decathlon_Daily_Delivery_Report_${SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())}.pdf")
            val outputStream = FileOutputStream(file)
            pdfDocument.writeTo(outputStream)
            pdfDocument.close()
            outputStream.flush()
            outputStream.close()
            return file
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    fun exportToExcel(context: Context, deliveries: List<Delivery>): File? {
        try {
            val sb = StringBuilder()
            // Excel CSV header row
            sb.append("Serial No,Order ID,Customer Name,Phone Number,Cycle Model,Delivery Status,Address,Delivery Date,OTP,OTP Verified,Driver,Feedback Stars,Feedback Comment,Completed Timestamp\n")

            deliveries.forEachIndexed { idx, d ->
                val cleanCustName = d.customerName.replace(",", " ")
                val cleanModel = d.cycleModel.replace(",", " ")
                val cleanStatus = d.deliveryStatus.replace(",", " ")
                val cleanAddress = d.address.replace(",", " ").replace("\n", " ")
                val cleanDriver = d.staffName.replace(",", " ")
                val cleanComment = (d.feedbackComment ?: "").replace(",", " ").replace("\n", " ")

                sb.append("${idx + 1},")
                    .append("${d.orderId},")
                    .append("$cleanCustName,")
                    .append("${d.phoneNumber},")
                    .append("$cleanModel,")
                    .append("$cleanStatus,")
                    .append("$cleanAddress,")
                    .append("${d.deliveryDate},")
                    .append("${d.otp},")
                    .append("${d.otpVerified},")
                    .append("$cleanDriver,")
                    .append("${d.feedbackRating ?: ""},")
                    .append("$cleanComment,")
                    .append("${d.deliveryCompletedTime ?: ""}\n")
            }

            val dir = context.getExternalFilesDir("documents") ?: context.filesDir
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, "Decathlon_Delivery_Statement_${SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())}.csv")
            file.writeText(sb.toString())
            return file
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    fun shareFile(context: Context, file: File, mimeType: String) {
        try {
            val uri: Uri = FileProvider.getUriForFile(context, "com.example.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Decathlon CycleDelivery Log Report")
                putExtra(Intent.EXTRA_TEXT, "Hello, sharing the CycleDelivery daily summary report document. Please refer to the attachment.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Delivery Report File using..."))
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Error sharing report: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    fun shareTextDetails(context: Context, text: String) {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Decathlon CycleDelivery Report Text Summary")
                putExtra(Intent.EXTRA_TEXT, text)
            }
            context.startActivity(Intent.createChooser(intent, "Share Text Details..."))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
