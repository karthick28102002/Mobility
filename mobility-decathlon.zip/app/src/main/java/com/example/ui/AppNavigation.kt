package com.example.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.net.Uri
import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.io.FileOutputStream
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.HelpCenter
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.Admin
import com.example.data.local.Delivery
import com.example.data.local.FeedbackEntry
import com.example.data.local.StaffMember
import com.example.ui.theme.*
import com.example.viewmodel.DeliveryViewModel
import kotlinx.coroutines.launch
import java.util.*

enum class AppScreen(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    BOOKING("Book Delivery", Icons.Default.DirectionsBike),
    TRACKING("Track Order", Icons.Default.LocationOn),
    GALLERY("Catalog", Icons.Default.GridView),
    ADMIN_LOGIN("Admin Login", Icons.Default.Lock),
    ADMIN_DASHBOARD("Admin Panel", Icons.Default.AdminPanelSettings),
    REPORTS("Reports Log", Icons.Default.Assessment),
    ABOUT("About Decathlon", Icons.Default.Info)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppView(viewModel: DeliveryViewModel, widthSizeClass: String = "Compact") {
    val context = LocalContext.current
    var currentScreen by remember { mutableStateOf(AppScreen.HOME) }

    // Observers
    val deliveries by viewModel.deliveries.collectAsState()
    val filteredDeliveries by viewModel.filteredDeliveries.collectAsState()
    val staffMembers by viewModel.staffMembers.collectAsState()
    val feedbackList by viewModel.feedbackList.collectAsState()
    val adminsList by viewModel.admins.collectAsState()
    val loggedInAdmin = viewModel.loggedInAdmin

    // Manage toasts/alerts at top of main view
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(viewModel.successToastMessage, viewModel.errorToastMessage) {
        viewModel.successToastMessage?.let {
            snackbarHostState.showSnackbar(it, duration = SnackbarDuration.Short)
            viewModel.clearToasts()
        }
        viewModel.errorToastMessage?.let {
            snackbarHostState.showSnackbar(it, duration = SnackbarDuration.Short)
            viewModel.clearToasts()
        }
    }

    // Dynamic state for auto feedback dialog
    var showAutoFeedbackDialog by remember { mutableStateOf(false) }
    var autoFeedbackRating by remember { mutableStateOf(5.0f) }
    var autoFeedbackComment by remember { mutableStateOf("") }

    LaunchedEffect(viewModel.activeDeliveryForFeedback) {
        if (viewModel.activeDeliveryForFeedback != null) {
            showAutoFeedbackDialog = true
            autoFeedbackRating = 5.0f;
            autoFeedbackComment = ""
        }
    }

    // Dialog for OTP Entry on Status Delivered Transition
    var showOtpDialog by remember { mutableStateOf(false) }
    var otpTargetDelivery by remember { mutableStateOf<Delivery?>(null) }
    var enteredOtpCode by remember { mutableStateOf("") }

    fun triggerOtpVerification(delivery: Delivery) {
        otpTargetDelivery = delivery
        enteredOtpCode = ""
        showOtpDialog = true
    }

    // Modal Drawer state for Menu
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    // Determine layout approach based on size class (Adaptive Layout)
    val isExpanded = widthSizeClass == "Expanded"

    // Automated redirect from Catalog Book now
    val onBookNavigateFromCatalog: (String) -> Unit = { modelName ->
        currentScreen = AppScreen.BOOKING
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = !isExpanded,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.width(300.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(DecathlonBlue, DecathlonDarkPrimary)
                            )
                        )
                        .padding(24.dp)
                ) {
                    Column {
                        DecathlonCycleLogo(
                            modifier = Modifier
                                .size(70.dp)
                                .align(Alignment.CenterHorizontally)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "DECATHLON CYCLES",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            "Marina Mall, Chennai",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(AppScreen.values()) { screen ->
                        // Hide Admin Panel representation if not logged in
                        if (screen == AppScreen.ADMIN_DASHBOARD && loggedInAdmin == null) {
                            return@items
                        }
                        if (screen == AppScreen.REPORTS && loggedInAdmin == null) {
                            return@items
                        }
                        if (screen == AppScreen.ADMIN_LOGIN && loggedInAdmin != null) {
                            return@items
                        }

                        NavigationDrawerItem(
                            icon = { Icon(screen.icon, contentDescription = screen.label) },
                            label = { Text(screen.label) },
                            selected = currentScreen == screen,
                            onClick = {
                                currentScreen = screen
                                androidx.compose.ui.platform.LocalFocusManager
                                coroutineScope.launch { drawerState.close() }
                            },
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = DecathlonBlue.copy(alpha = 0.15f),
                                selectedIconColor = DecathlonBlue,
                                selectedTextColor = DecathlonBlue
                            ),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                        )
                    }
                    if (loggedInAdmin != null) {
                        item {
                            HorizontalDivider(modifier = Modifier.padding(16.dp))
                            Text(
                                "Logged in: ${loggedInAdmin.fullName}",
                                modifier = Modifier.padding(start = 24.dp, bottom = 8.dp),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.Gray
                            )
                            NavigationDrawerItem(
                                icon = { Icon(Icons.Default.Logout, contentDescription = "Logout") },
                                label = { Text("Logout Admin") },
                                selected = false,
                                onClick = {
                                    viewModel.logoutAdmin()
                                    currentScreen = AppScreen.HOME
                                    coroutineScope.launch { drawerState.close() }
                                },
                                modifier = Modifier.padding(horizontal = 12.dp)
                            )
                        }
                    }
                }
            }
        }
    ) {
        Row(modifier = Modifier.fillMaxSize()) {
            // Expanded Layout sidebar
            if (isExpanded) {
                NavigationRail(
                    containerColor = DecathlonBlue,
                    contentColor = Color.White,
                    header = {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(vertical = 16.dp)
                        ) {
                            DecathlonCycleLogo(modifier = Modifier.size(50.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Decathlon", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                ) {
                    AppScreen.values().forEach { screen ->
                        if (screen == AppScreen.ADMIN_DASHBOARD && loggedInAdmin == null) return@forEach
                        if (screen == AppScreen.REPORTS && loggedInAdmin == null) return@forEach
                        if (screen == AppScreen.ADMIN_LOGIN && loggedInAdmin != null) return@forEach

                        NavigationRailItem(
                            icon = { Icon(screen.icon, contentDescription = screen.label) },
                            label = { Text(screen.label, fontSize = 10.sp) },
                            selected = currentScreen == screen,
                            onClick = { currentScreen = screen },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = DecathlonBlue,
                                selectedTextColor = Color.White,
                                unselectedIconColor = Color.White.copy(0.7f),
                                unselectedTextColor = Color.White.copy(0.7f),
                                indicatorColor = Color.White
                            )
                        )
                    }
                    if (loggedInAdmin != null) {
                        Spacer(modifier = Modifier.weight(1f))
                        NavigationRailItem(
                            icon = { Icon(Icons.Default.Logout, contentDescription = "Logout") },
                            label = { Text("Logout", fontSize = 10.sp) },
                            selected = false,
                            onClick = {
                                viewModel.logoutAdmin()
                                currentScreen = AppScreen.HOME
                            },
                            colors = NavigationRailItemDefaults.colors(
                                unselectedIconColor = Color.White,
                                unselectedTextColor = Color.White
                            )
                        )
                    }
                }
            }

            // Screen Content Area
            Scaffold(
                topBar = {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp)),
                        color = DecathlonBlue,
                        shadowElevation = 8.dp
                    ) {
                        CenterAlignedTopAppBar(
                            title = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    DecathlonCycleLogo(modifier = Modifier.size(36.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        currentScreen.label,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 20.sp,
                                        color = Color.White
                                    )
                                }
                            },
                            navigationIcon = {
                                if (!isExpanded) {
                                    IconButton(
                                        onClick = {
                                            coroutineScope.launch { drawerState.open() }
                                        },
                                        colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)
                                    ) {
                                        Icon(Icons.Default.Menu, contentDescription = "Menu")
                                    }
                                }
                            },
                            actions = {
                                if (loggedInAdmin != null) {
                                    // Live Cloud Sync shortcut refresh button
                                    if (viewModel.isSyncEnabled && viewModel.syncBaseUrl.isNotBlank()) {
                                        IconButton(
                                            onClick = { viewModel.performCloudSync() },
                                            enabled = !viewModel.isSyncing,
                                            colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)
                                        ) {
                                            if (viewModel.isSyncing) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(16.dp),
                                                    color = Color.White,
                                                    strokeWidth = 2.dp
                                                )
                                            } else {
                                                Icon(
                                                    imageVector = Icons.Default.Sync,
                                                    contentDescription = "Trigger Sync"
                                                )
                                            }
                                        }
                                    }
                                    IconButton(
                                        onClick = { currentScreen = AppScreen.ADMIN_DASHBOARD },
                                        colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)
                                    ) {
                                        Icon(Icons.Default.AdminPanelSettings, contentDescription = "Dashboard")
                                    }
                                } else {
                                    IconButton(
                                        onClick = { currentScreen = AppScreen.ADMIN_LOGIN },
                                        colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)
                                    ) {
                                        Icon(Icons.Default.LockOpen, contentDescription = "Admin login")
                                    }
                                }
                            },
                            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                containerColor = Color.Transparent
                            )
                        )
                    }
                },
                bottomBar = {
                    // bottom navigation on mobile screen (Compact Mode)
                    if (!isExpanded) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)),
                            color = Color.White,
                            shadowElevation = 12.dp
                        ) {
                            NavigationBar(
                                containerColor = Color.Transparent,
                                tonalElevation = 0.dp
                            ) {
                                val mainTabs = listOf(AppScreen.HOME, AppScreen.BOOKING, AppScreen.TRACKING, AppScreen.GALLERY)
                                mainTabs.forEach { tab ->
                                    NavigationBarItem(
                                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                                        label = { Text(tab.label, fontSize = 10.sp) },
                                        selected = currentScreen == tab,
                                        onClick = { currentScreen = tab },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = Color.White,
                                            selectedTextColor = DecathlonBlue,
                                            indicatorColor = DecathlonBlue,
                                            unselectedIconColor = Color.Gray,
                                            unselectedTextColor = Color.Gray
                                        )
                                    )
                                }
                            }
                        }
                    }
                },
                snackbarHost = { SnackbarHost(snackbarHostState) },
                containerColor = DecathlonLightBg
            ) { paddingValues ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    AnimatedContent(
                        targetState = currentScreen,
                        transitionSpec = {
                            fadeIn() togetherWith fadeOut()
                        },
                        label = "screen_switch"
                    ) { targetScreen ->
                        when (targetScreen) {
                            AppScreen.HOME -> HomeScreen(
                                viewModel = viewModel,
                                onNavigateTo = { currentScreen = it }
                            )
                            AppScreen.BOOKING -> DeliveryEntryScreen(
                                viewModel = viewModel,
                                staffList = staffMembers,
                                onBookingSuccess = { currentScreen = AppScreen.HOME }
                            )
                            AppScreen.TRACKING -> TrackingScreen(
                                viewModel = viewModel
                            )
                            AppScreen.GALLERY -> GalleryScreen(
                                onNavigateToBook = { selectedModel ->
                                    currentScreen = AppScreen.BOOKING
                                }
                            )

                            AppScreen.ADMIN_LOGIN -> AdminLoginScreen(
                                viewModel = viewModel,
                                onSuccessfulLogin = { currentScreen = AppScreen.ADMIN_DASHBOARD }
                            )
                            AppScreen.ADMIN_DASHBOARD -> {
                                if (loggedInAdmin != null) {
                                    AdminDashboardScreen(
                                        viewModel = viewModel,
                                        deliveries = filteredDeliveries,
                                        staffList = staffMembers,
                                        adminsList = adminsList,
                                        loggedInAdmin = loggedInAdmin,
                                        onVerifyOtpFor = { delivery -> triggerOtpVerification(delivery) }
                                    )
                                } else {
                                    currentScreen = AppScreen.ADMIN_LOGIN
                                }
                            }
                            AppScreen.REPORTS -> {
                                if (loggedInAdmin != null) {
                                    ReportsScreen(
                                        viewModel = viewModel,
                                        deliveries = deliveries,
                                        feedbacks = feedbackList
                                    )
                                } else {
                                    AdminLoginScreen(
                                        viewModel = viewModel,
                                        onSuccessfulLogin = { currentScreen = AppScreen.REPORTS }
                                    )
                                }
                            }
                            AppScreen.ABOUT -> AboutScreen()
                        }
                    }

                    // Automated customer feedback pop up when delivery is marked Delivered
                    if (showAutoFeedbackDialog && viewModel.activeDeliveryForFeedback != null) {
                        val active = viewModel.activeDeliveryForFeedback!!
                        Dialog(onDismissRequest = { 
                            showAutoFeedbackDialog = false
                            viewModel.activeDeliveryForFeedback = null
                        }) {
                            Card(
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .padding(24.dp)
                                        .fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ThumbUp,
                                        contentDescription = "Success",
                                        tint = DecathlonActiveOrange,
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        "Order Delivered!",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 20.sp,
                                        color = DecathlonBlue
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        "Hi ${active.customerName}, your cycle ${active.cycleModel} has been delivered. Please share your rating:",
                                        fontSize = 14.sp,
                                        textAlign = TextAlign.Center,
                                        color = Color.DarkGray
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    InteractiveStarRatingBar(
                                        rating = autoFeedbackRating,
                                        onRatingChanged = { autoFeedbackRating = it }
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    OutlinedTextField(
                                        value = autoFeedbackComment,
                                        onValueChange = { autoFeedbackComment = it },
                                        label = { Text("Customer Feedback/Comments") },
                                        modifier = Modifier.fillMaxWidth(),
                                        maxLines = 3
                                    )
                                    Spacer(modifier = Modifier.height(20.dp))
                                    Button(
                                        onClick = {
                                            viewModel.submitFeedback(
                                                customerName = active.customerName,
                                                phoneNumber = active.phoneNumber,
                                                rating = autoFeedbackRating,
                                                comment = if (autoFeedbackComment.isNotBlank()) autoFeedbackComment else "Instant verified delivery rating.",
                                                deliveryId = active.id,
                                                onSuccess = {
                                                    showAutoFeedbackDialog = false
                                                }
                                            )
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DecathlonBlue)
                                    ) {
                                        Text("Submit Feedback")
                                    }
                                }
                            }
                        }
                    }

                    // OTP Delivery Verification Modal
                    if (showOtpDialog && otpTargetDelivery != null) {
                        val active = otpTargetDelivery!!
                        Dialog(onDismissRequest = { showOtpDialog = false }) {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VpnKey,
                                        tint = DecathlonBlue,
                                        contentDescription = "OTP Verify",
                                        modifier = Modifier.size(40.dp)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        "OTP Verification",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = DecathlonBlue
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        "Customer: ${active.customerName}\nOrder: ${active.orderId}",
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center,
                                        color = Color.Gray
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        "A secure OTP was sent to applicant's phone ${active.phoneNumber}. Please enter the 4-digit code to conclude delivery:",
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    
                                    // Hint helper for virtual environment (admins can see OTP here)
                                    Surface(
                                        color = DecathlonLightBg,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.padding(bottom = 12.dp)
                                    ) {
                                        Text(
                                            "Virtual SMS Sim: Active OTP Code is ${active.otp}",
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = DecathlonBlue
                                        )
                                    }

                                    OutlinedTextField(
                                        value = enteredOtpCode,
                                        onValueChange = { if (it.length <= 6) enteredOtpCode = it },
                                        placeholder = { Text("Enter OTP Code") },
                                        singleLine = true,
                                        textStyle = LocalTextStyle.current.copy(
                                            textAlign = TextAlign.Center,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 18.sp
                                        ),
                                        modifier = Modifier
                                            .width(180.dp)
                                            .testTag("otp_input")
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        OutlinedButton(onClick = { showOtpDialog = false }) {
                                            Text("Cancel")
                                        }
                                        Button(
                                            onClick = {
                                                viewModel.verifyOtpFlow(
                                                    deliveryId = active.id,
                                                    enteredOtp = enteredOtpCode,
                                                    onSuccess = {
                                                        showOtpDialog = false
                                                    }
                                                )
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = DecathlonSuccessGreen)
                                        ) {
                                            Text("Verify & Complete")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 1. HOME SCREEN SECTION
@Composable
fun HomeScreen(viewModel: DeliveryViewModel, onNavigateTo: (AppScreen) -> Unit) {
    val deliveries by viewModel.deliveries.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Welcoming Hero Branding Box with embedded dynamic metrics row (matching design header layout)
        Card(
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(DecathlonBlue, DecathlonDarkPrimary)
                        )
                    )
                    .padding(vertical = 24.dp, horizontal = 20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Decathlon Chennai",
                                color = DecathlonActiveOrange,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Mobility Decathlon",
                                color = Color.White,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Professional assembly, custom setup & swift secure-OTP home deliveries.",
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                        DecathlonCycleLogo(
                            modifier = Modifier
                                .size(72.dp)
                                .padding(4.dp),
                            animateSpeedMs = 4000
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Horizontal Summary Metrics directly reflecting the design's header info bars
                    val total = deliveries.size
                    val inTransit = deliveries.count { it.deliveryStatus == "Out for Delivery" || it.deliveryStatus == "Delivery Person Assigned" }
                    val completed = deliveries.count { it.deliveryStatus == "Delivered" }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Total Today
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Column {
                                Text("Total Today", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f), fontWeight = FontWeight.Medium)
                                Text("$total Units", fontSize = 15.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                        // In Transit / Pending
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Column {
                                Text("Pending / Transit", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f), fontWeight = FontWeight.Medium)
                                Text("$inTransit Units", fontSize = 15.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                        // Completed
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Column {
                                Text("Completed", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f), fontWeight = FontWeight.Medium)
                                Text("$completed Units", fontSize = 15.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Fast Lookup Tool
        Text("Real-Time Order Tracking Lookup", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DecathlonBlue)
        Spacer(modifier = Modifier.height(8.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, DecathlonLightGrey, RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                var orderSearch by remember { mutableStateOf("") }
                Text(
                    "Check live cycle packing, assignment, transit, or delivery progress:",
                    fontSize = 12.sp,
                    color = Color.DarkGray
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = orderSearch,
                        onValueChange = { orderSearch = it },
                        placeholder = { Text("Enter Order ID or Mobile (e.g. DEC-54319)") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("home_track_input")
                    )
                    Button(
                        onClick = {
                            viewModel.trackedOrderQuery = orderSearch
                            viewModel.trackDeliveryByOrderId(orderSearch)
                            onNavigateTo(AppScreen.TRACKING)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DecathlonBlue)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Lookup")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Track")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Navigation Action Portal Buttons
        Text("Quick Actions", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DecathlonBlue)
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, DecathlonLightGrey, RoundedCornerShape(16.dp))
                    .clickable { onNavigateTo(AppScreen.BOOKING) },
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(DecathlonBlue.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.PostAdd, contentDescription = "Add", tint = DecathlonBlue, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("New Booking", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Customer Form", fontSize = 10.sp, color = Color.Gray, textAlign = TextAlign.Center)
                }
            }
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, DecathlonLightGrey, RoundedCornerShape(16.dp))
                    .clickable { onNavigateTo(AppScreen.GALLERY) },
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(DecathlonBlue.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.GridView, contentDescription = "Gallery", tint = DecathlonBlue, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Model Gallery", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Explore Catalog", fontSize = 10.sp, color = Color.Gray, textAlign = TextAlign.Center)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, DecathlonLightGrey, RoundedCornerShape(16.dp))
                .clickable { onNavigateTo(AppScreen.ABOUT) },
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(DecathlonBlue.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Storefront, contentDescription = "About", tint = DecathlonBlue, modifier = Modifier.size(24.dp))
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text("Marina Store", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("Address & Info", fontSize = 10.sp, color = Color.Gray, textAlign = TextAlign.Center)
            }
        }

        // Active Deliveries Live Feed (Matching Active Deliveries card style from Design HTML)
        Spacer(modifier = Modifier.height(24.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Active Deliveries Live Feed", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DecathlonBlue)
            Text(
                "View All",
                color = DecathlonBlue,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onNavigateTo(AppScreen.ADMIN_LOGIN) }
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        val activeDeliveries = deliveries.filter { it.deliveryStatus != "Delivered" }.take(3)
        if (activeDeliveries.isEmpty()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DecathlonLightGrey, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.DoneAll, contentDescription = "Done", tint = DecathlonSuccessGreen, modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("All cycles delivered successfully!", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("No pending active deliveries.", fontSize = 11.sp, color = Color.Gray)
                }
            }
        } else {
            activeDeliveries.forEach { active ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .border(1.dp, DecathlonLightGrey, RoundedCornerShape(16.dp))
                        .clickable {
                            viewModel.trackedOrderQuery = active.orderId
                            viewModel.trackDeliveryByOrderId(active.orderId)
                            onNavigateTo(AppScreen.TRACKING)
                        },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        DeliveryPhotoRepresentation(
                            photoUri = active.photoUri,
                            cycleModel = active.cycleModel,
                            size = 48.dp
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(active.cycleModel, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                                Surface(
                                    color = when (active.deliveryStatus) {
                                        "Out for Delivery" -> DecathlonActiveOrange.copy(0.12f)
                                        else -> DecathlonBlue.copy(0.12f)
                                    },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        active.deliveryStatus.uppercase(),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = when (active.deliveryStatus) {
                                            "Out for Delivery" -> DecathlonActiveOrange
                                            else -> DecathlonBlue
                                        }
                                    )
                                }
                            }
                            Text("ID: ${active.orderId} • ${active.customerName}", fontSize = 11.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(6.dp))
                            // Simple linear tracking progress bar
                            val progress = when (active.deliveryStatus) {
                                "Booking" -> 0.15f
                                "Booked" -> 0.4f
                                "Delivery Person Assigned" -> 0.65f
                                "Out for Delivery" -> 0.85f
                                else -> 1.0f
                            }
                            LinearProgressIndicator(
                                progress = progress,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp)),
                                color = DecathlonBlue,
                                trackColor = DecathlonLightGrey
                            )
                        }
                    }
                }
            }
        }
    }


}

// 2. CUSTOMER DELIVERY FORM SCREEN
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DeliveryEntryScreen(
    viewModel: DeliveryViewModel,
    staffList: List<StaffMember>,
    onBookingSuccess: () -> Unit
) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current

    // Form parameter inputs
    var customerName by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var orderId by remember { mutableStateOf("") }

    // Dropdowns and selection options
    val catalogCycles = CycleCatalog.items
    var selectedCycleIndex by remember { mutableStateOf(1) } // Default Rockrider ST 120
    var expandedCycleDropdown by remember { mutableStateOf(false) }
    var cycleModelInputState by remember { mutableStateOf(catalogCycles[1].name) }

    // Automatically auto-generate an unique Decathlon Order ID
    LaunchedEffect(Unit) {
        val rand = (10000..99999).random()
        orderId = "DEC-$rand"
    }

    // Picker Dates/Time
    val calendar = Calendar.getInstance()
    var dateString by remember { 
        mutableStateOf(
            String.format(Locale.getDefault(), "%04d-%02d-%02d", 
                calendar.get(Calendar.YEAR), 
                calendar.get(Calendar.MONTH) + 1, 
                calendar.get(Calendar.DAY_OF_MONTH)
            )
        ) 
    }
    var timeString by remember { mutableStateOf("11:00 AM") }

    // Picker trigger helpers
    val datePickerDialog = DatePickerDialog(
        context,
        { _, yr, mo, dy ->
            dateString = String.format(Locale.getDefault(), "%04d-%02d-%02d", yr, mo + 1, dy)
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    val timePickerDialog = TimePickerDialog(
        context,
        { _, hr, min ->
            val ampm = if (hr >= 12) "PM" else "AM"
            val displayHr = if (hr > 12) hr - 12 else if (hr == 0) 12 else hr
            timeString = String.format(Locale.getDefault(), "%02d:%02d %s", displayHr, min, ampm)
        },
        11, 0, false
    )

    // Photo Select preset helper
    var selectedPhotoPreset by remember { mutableStateOf("preset_rockrider") }

    var customPhotoUriStr by remember { mutableStateOf<String?>(null) }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            customPhotoUriStr = uri.toString()
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            val file = File(context.cacheDir, "booking_${System.currentTimeMillis()}.jpg")
            try {
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                }
                customPhotoUriStr = Uri.fromFile(file).toString()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Failed to save snapped picture file: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Staff allocation
    var selectedStaffName by remember { mutableStateOf("Karthik Kumar") }
    var expandedStaffDropdown by remember { mutableStateOf(false) }

    // Quick status
    var deliveryStatus by remember { mutableStateOf("Booked") } // Booking -> Booked -> Persons Assigned -> Out for Delivery

    // Delivery Method selection
    var deliveryMethod by remember { mutableStateOf("Store Delivery") } // ACE Order, Customer Pickup, Store Delivery
    var expandedMethodDropdown by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text("Customer Information", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DecathlonBlue)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = customerName,
                    onValueChange = { customerName = it },
                    label = { Text("Customer Name *") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = "Name") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("form_name")
                )

                OutlinedTextField(
                    value = phoneNumber,
                    onValueChange = { if (it.all { ch -> ch.isDigit() || ch == ' ' || ch == '+' }) phoneNumber = it },
                    label = { Text("Phone Number *") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = "Phone") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("form_phone")
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Delivery Address *") },
                    maxLines = 3,
                    leadingIcon = { Icon(Icons.Default.Home, contentDescription = "Address") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("form_address")
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text("Cycle Booking Details", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DecathlonBlue)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Order ID Display (Autogenerated)
                OutlinedTextField(
                    value = orderId,
                    onValueChange = { orderId = it.uppercase() },
                    label = { Text("Order ID *") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Receipt, contentDescription = "Order ID") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Select Cycle Model with typing options and filtered lookup suggestions
                Box {
                    val filteredCycles = if (cycleModelInputState.isBlank()) {
                        catalogCycles
                    } else {
                        catalogCycles.filter { it.name.contains(cycleModelInputState, ignoreCase = true) }
                    }
                    OutlinedTextField(
                        value = cycleModelInputState,
                        onValueChange = { 
                            cycleModelInputState = it
                            // Dynamically lookup to see if custom typed value matches any pre-defined model
                            val foundIdx = catalogCycles.indexOfFirst { cycle -> cycle.name.equals(it, ignoreCase = true) }
                            if (foundIdx != -1) {
                                selectedCycleIndex = foundIdx
                                selectedPhotoPreset = catalogCycles[foundIdx].presetPhotoId
                            }
                        },
                        label = { Text("Cycle Model * (Type or Select)") },
                        trailingIcon = { 
                            IconButton(onClick = { expandedCycleDropdown = true }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Select")
                            } 
                        },
                        leadingIcon = { Icon(Icons.Default.DirectionsBike, contentDescription = "Cycle") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    DropdownMenu(
                        expanded = expandedCycleDropdown,
                        onDismissRequest = { expandedCycleDropdown = false }
                    ) {
                        filteredCycles.forEach { cycle ->
                            DropdownMenuItem(
                                text = { Text("${cycle.name} (${cycle.category} - ${cycle.price})") },
                                onClick = {
                                    val idx = catalogCycles.indexOfFirst { it.id == cycle.id }
                                    if (idx != -1) {
                                        selectedCycleIndex = idx
                                    }
                                    cycleModelInputState = cycle.name
                                    selectedPhotoPreset = cycle.presetPhotoId
                                    expandedCycleDropdown = false
                                }
                            )
                        }
                        if (filteredCycles.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text("Using custom cycle: '$cycleModelInputState'") },
                                onClick = { expandedCycleDropdown = false },
                                enabled = false
                            )
                        }
                    }
                }

                // Choose Preset Visual Photo representation
                Text("Simulated Cycle Photo", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(DecathlonLightBg)
                            .border(1.dp, DecathlonBlue, RoundedCornerShape(8.dp))
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        DecathlonCycleLogo(
                            primaryColor = catalogCycles[selectedCycleIndex].accentColor,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            "Preset linked: $cycleModelInputState",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Automatically matches Decathlon model catalogue branding.",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                
                // Add Photo Option Section
                Text("Booking Photo Attachment", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DecathlonBlue)
                
                Card(
                    colors = CardDefaults.cardColors(containerColor = DecathlonLightBg.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            "Add a photo of the physical bicycle, customer handover, or parcel packing for tracking proof:", 
                            fontSize = 11.sp, 
                            color = Color.DarkGray
                        )
                        
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Selected Custom Image Preview Framework
                            Box(
                                modifier = Modifier
                                    .size(75.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.White)
                                    .border(1.dp, if (customPhotoUriStr != null) DecathlonBlue else Color.LightGray, RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (customPhotoUriStr != null) {
                                    coil.compose.AsyncImage(
                                        model = customPhotoUriStr,
                                        contentDescription = "Selected Booking Photo Preview",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                    )
                                } else {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.AddAPhoto, contentDescription = "Camera Icon", tint = Color.LightGray, modifier = Modifier.size(24.dp))
                                        Text("No Photo", fontSize = 9.sp, color = Color.Gray)
                                    }
                                }
                            }
                            
                            // Actions
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    // Camera Snap Launcher
                                    Button(
                                        onClick = {
                                            try {
                                                cameraLauncher.launch(null)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "Camera failed or unavailable in this environment.", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DecathlonBlue),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1f).height(36.dp)
                                    ) {
                                        Icon(Icons.Default.PhotoCamera, contentDescription = "Snap", modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Snap", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                    
                                    // Gallery Picker
                                    Button(
                                        onClick = {
                                            try {
                                                galleryLauncher.launch("image/*")
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "Gallery failed or unavailable.", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1f).height(36.dp)
                                    ) {
                                        Icon(Icons.Default.Collections, contentDescription = "Gallery", tint = Color.DarkGray, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Gallery", color = Color.DarkGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                
                                // Simulated Snapshot options (especially useful for server side applet!)
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Button(
                                        onClick = {
                                            // Mock/Simulate standard high-quality brand cycle photo
                                            val stockBicycles = listOf(
                                                "https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&q=80&w=400",
                                                "https://images.unsplash.com/photo-1532298229144-0ec0c57515c7?auto=format&fit=crop&q=80&w=400",
                                                "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=400",
                                                "https://images.unsplash.com/photo-1544192240-4a34fed0104c?auto=format&fit=crop&q=80&w=400"
                                            )
                                            customPhotoUriStr = stockBicycles.random()
                                            Toast.makeText(context, "Simulated Brand bicycle photo attached!", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DecathlonActiveOrange),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth().height(36.dp)
                                    ) {
                                        Icon(Icons.Default.Bolt, contentDescription = "Simulate", modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Simulate Handover Photo", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        
                        // Custom Web Link (URL) field for testing or remote uploading
                        var photoUrlInput by remember { mutableStateOf("") }
                        OutlinedTextField(
                            value = photoUrlInput,
                            onValueChange = { 
                                photoUrlInput = it
                                if (it.isNotBlank()) {
                                    customPhotoUriStr = it.trim()
                                } else {
                                    customPhotoUriStr = null
                                }
                            },
                            placeholder = { Text("Paste custom image/web photo URL (optional)") },
                            singleLine = true,
                            leadingIcon = { Icon(Icons.Default.Link, contentDescription = "Link") },
                            modifier = Modifier.fillMaxWidth(),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp)
                        )
                        
                        if (customPhotoUriStr != null) {
                            Button(
                                onClick = { 
                                    customPhotoUriStr = null
                                    photoUrlInput = ""
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                contentPadding = PaddingValues(0.dp),
                                modifier = Modifier.align(Alignment.End).height(24.dp)
                            ) {
                                Text("Clear Attachment & Use Preset", color = Color.Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Date Time Pickers
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = dateString,
                        onValueChange = {},
                        label = { Text("Delivery Date") },
                        readOnly = true,
                        trailingIcon = {
                            IconButton(onClick = { datePickerDialog.show() }) {
                                Icon(Icons.Default.CalendarToday, contentDescription = "Pick Date")
                            }
                        },
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = timeString,
                        onValueChange = {},
                        label = { Text("Delivery Time") },
                        readOnly = true,
                        trailingIcon = {
                            IconButton(onClick = { timePickerDialog.show() }) {
                                Icon(Icons.Default.AccessTime, contentDescription = "Pick Time")
                            }
                        },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Staff Delivery Allocation Dropdown
                Box {
                    val names = if (staffList.isNotEmpty()) staffList.map { it.name } else listOf("Karthik Kumar", "Ramesh Chandran", "Anitha Raj")
                    OutlinedTextField(
                        value = selectedStaffName,
                        onValueChange = {},
                        label = { Text("Delivery Staff Assigned") },
                        readOnly = true,
                        trailingIcon = { 
                            IconButton(onClick = { expandedStaffDropdown = true }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Select")
                            } 
                        },
                        leadingIcon = { Icon(Icons.Default.SupervisedUserCircle, contentDescription = "Staff") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    DropdownMenu(
                        expanded = expandedStaffDropdown,
                        onDismissRequest = { expandedStaffDropdown = false }
                    ) {
                        names.forEach { name ->
                            DropdownMenuItem(
                                text = { Text(name) },
                                onClick = {
                                    selectedStaffName = name
                                    expandedStaffDropdown = false
                                }
                            )
                        }
                    }
                }

                // Default Delivery status
                Box {
                    var expandedStatusDropdown by remember { mutableStateOf(false) }
                    val statuses = listOf("Booking", "Booked", "Delivery Person Assigned", "Out for Delivery")
                    OutlinedTextField(
                        value = deliveryStatus,
                        onValueChange = {},
                        label = { Text("Starting Status") },
                        readOnly = true,
                        trailingIcon = { 
                            IconButton(onClick = { expandedStatusDropdown = true }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Select")
                            } 
                        },
                        leadingIcon = { Icon(Icons.Default.Autorenew, contentDescription = "Status") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    DropdownMenu(
                        expanded = expandedStatusDropdown,
                        onDismissRequest = { expandedStatusDropdown = false }
                    ) {
                        statuses.forEach { status ->
                            DropdownMenuItem(
                                text = { Text(status) },
                                onClick = {
                                    deliveryStatus = status
                                    expandedStatusDropdown = false
                                }
                            )
                        }
                    }
                }

                // Delivery Method selection Option
                Box {
                    val methods = listOf("ACE Order", "Customer Pickup", "Store Delivery")
                    OutlinedTextField(
                        value = deliveryMethod,
                        onValueChange = {},
                        label = { Text("Delivery Method *") },
                        readOnly = true,
                        trailingIcon = { 
                            IconButton(onClick = { expandedMethodDropdown = true }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Select")
                            } 
                        },
                        leadingIcon = { Icon(Icons.Default.LocalShipping, contentDescription = "Method") },
                        modifier = Modifier.fillMaxWidth().testTag("form_delivery_method")
                    )
                    DropdownMenu(
                        expanded = expandedMethodDropdown,
                        onDismissRequest = { expandedMethodDropdown = false }
                    ) {
                        methods.forEach { method ->
                            DropdownMenuItem(
                                text = { Text(method) },
                                onClick = {
                                    deliveryMethod = method
                                    expandedMethodDropdown = false
                                }
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Save Button
        Button(
            onClick = {
                viewModel.createDelivery(
                    customerName = customerName,
                    phoneNumber = phoneNumber,
                    cycleModel = cycleModelInputState,
                    orderId = orderId,
                    address = address,
                    deliveryDate = dateString,
                    deliveryTime = timeString,
                    photoUri = customPhotoUriStr ?: selectedPhotoPreset,
                    staffName = selectedStaffName,
                    deliveryStatus = deliveryStatus,
                    deliveryMethod = deliveryMethod,
                    onSuccess = {
                        onBookingSuccess()
                    }
                )
            },
            colors = ButtonDefaults.buttonColors(containerColor = DecathlonBlue),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("submit_delivery_button")
        ) {
            Icon(Icons.Default.Save, contentDescription = "Submit")
            Spacer(modifier = Modifier.width(8.dp))
            Text("Create Delivery Order", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

// 3. REAL-TIME DELIVERY TIMELINE TRACKER
@Composable
fun TrackingScreen(viewModel: DeliveryViewModel) {
    val delivery = viewModel.trackedDelivery
    val error = viewModel.trackError

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Search Active Orders", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DecathlonBlue)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = viewModel.trackedOrderQuery,
                        onValueChange = { viewModel.trackedOrderQuery = it },
                        placeholder = { Text("Order ID or Phone Number") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tracking_search_input")
                    )
                    Button(
                        onClick = { viewModel.trackDeliveryByOrderId(viewModel.trackedOrderQuery) },
                        colors = ButtonDefaults.buttonColors(containerColor = DecathlonBlue)
                    ) {
                        Text("Search")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (error != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Error, contentDescription = "Error", tint = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(error, fontSize = 14.sp)
                }
            }
        }

        if (delivery != null) {
            // Customer Info Details Overview Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("ORDER DETAILS", fontWeight = FontWeight.Bold, color = DecathlonBlue, fontSize = 12.sp)
                            Text(delivery.orderId, fontWeight = FontWeight.Black, fontSize = 20.sp)
                        }
                        Surface(
                            color = when (delivery.deliveryStatus) {
                                "Delivered" -> DecathlonSuccessGreen.copy(0.12f)
                                "Out for Delivery" -> DecathlonActiveOrange.copy(0.12f)
                                else -> DecathlonBlue.copy(0.12f)
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                delivery.deliveryStatus.uppercase(),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (delivery.deliveryStatus) {
                                    "Delivered" -> DecathlonSuccessGreen
                                    "Out for Delivery" -> DecathlonActiveOrange
                                    else -> DecathlonBlue
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        // Drawing Bike Visual matched to original
                        DeliveryPhotoRepresentation(
                            photoUri = delivery.photoUri,
                            cycleModel = delivery.cycleModel,
                            size = 80.dp
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            Text("Customer: ${delivery.customerName}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Phone: ${delivery.phoneNumber}", fontSize = 12.sp, color = Color.Gray)
                            Text("Address: ${delivery.address}", fontSize = 12.sp, color = Color.Gray, maxLines = 2)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Cycle Model: ${delivery.cycleModel}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = DecathlonBlue)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Real-Time Delivery Timeline node list
            Text("Delivery Progress Timeline", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DecathlonBlue)
            Spacer(modifier = Modifier.height(12.dp))

            val timelineSteps = listOf(
                "Booking" to "Order record initial entry received from booking counter.",
                "Booked" to "Bicycle allocated, technician pre-assembly and safety-check signed off.",
                "Delivery Person Assigned" to "Secured for transit, hand-off to team driver ${delivery.staffName}.",
                "Out for Delivery" to "Bicycle is packed on delivery rig, out for final destination.",
                "Delivered" to "Bicycle received. Safe-verification via Customer OTP verified."
            )

            // Finding index of current delivery status
            val currentStatusIdx = timelineSteps.indexOfFirst { it.first == delivery.deliveryStatus }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    timelineSteps.forEachIndexed { idx, step ->
                        val isCompleted = idx <= currentStatusIdx
                        val isActive = idx == currentStatusIdx

                        Row(modifier = Modifier.fillMaxWidth()) {
                            // Timeline visual line components
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.width(36.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (isCompleted) {
                                                if (isActive) DecathlonActiveOrange else DecathlonBlue
                                            } else Color.LightGray
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isCompleted) Icons.Default.Check else Icons.Default.Circle,
                                        contentDescription = "Step",
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                                if (idx < timelineSteps.size - 1) {
                                    Box(
                                        modifier = Modifier
                                            .width(3.dp)
                                            .height(50.dp)
                                            .background(if (idx < currentStatusIdx) DecathlonBlue else Color.LightGray)
                                    )
                                }
                            }

                            // Descriptive details of node
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(start = 12.dp, bottom = 16.dp)
                            ) {
                                Text(
                                    text = step.first,
                                    fontWeight = if (isActive) FontWeight.ExtraBold else FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = if (isActive) DecathlonActiveOrange else if (isCompleted) DecathlonBlue else Color.Gray
                                )
                                Text(
                                    text = step.second,
                                    fontSize = 11.sp,
                                    color = Color.DarkGray,
                                    lineHeight = 15.sp
                                )
                                if (step.first == "Delivery Person Assigned" && isCompleted) {
                                    Text(
                                        "Assigned Staff: ${delivery.staffName}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DecathlonBlue,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                                if (step.first == "Delivered" && isCompleted) {
                                    Text(
                                        "Delivered Completed: ${delivery.deliveryCompletedTime ?: delivery.deliveryDate}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DecathlonSuccessGreen,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Quick display of OTP for debug if pending verification
            if (delivery.deliveryStatus != "Delivered") {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = DecathlonBlue.copy(0.08f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.VpnKey, tint = DecathlonBlue, contentDescription = "OTP")
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "Delivery Verification Pending",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            "Secure OTP requested for completion: ${delivery.otp}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = DecathlonBlue
                        )
                        Text(
                            "Upon Hand-off, customer must provide this OTP to delivery staff.",
                            fontSize = 11.sp,
                            color = Color.DarkGray,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            if (error == null) {
                // Tracking empty/init state
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .padding(32.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PedalBike,
                            tint = Color.LightGray,
                            contentDescription = "Explore",
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "Know Where Your Cycle is!",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "Enter your order barcode ID (e.g. DEC-54319) or customer mobile to retrieve instant dispatch metrics, technician assembly checklists, and live driver updates.",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}

// 4. CYCLE GALLERY SCREEN
@Composable
fun GalleryScreen(onNavigateToBook: (String) -> Unit) {
    val catalog = CycleCatalog.items
    var selectedCategoryFilter by remember { mutableStateOf("All") }
    val categories = listOf("All", "Mountain", "Road", "Hybrid")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Category Filter row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            categories.forEach { cat ->
                FilterChip(
                    selected = selectedCategoryFilter == cat,
                    onClick = { selectedCategoryFilter = cat },
                    label = { Text(cat) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = DecathlonBlue,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        val filteredItems = if (selectedCategoryFilter == "All") {
            catalog
        } else {
            catalog.filter { it.category == selectedCategoryFilter }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredItems) { cycle ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // Drawing bike representation card top
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .background(
                                    Brush.verticalGradient(
                                        listOf(cycle.accentColor.copy(alpha = 0.35f), DecathlonLightBg)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            DecathlonCycleLogo(
                                primaryColor = cycle.accentColor,
                                secondaryColor = DecathlonActiveOrange,
                                modifier = Modifier
                                    .size(170.dp)
                                    .padding(8.dp)
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .align(Alignment.TopStart)
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = Color(0xFF0F2537),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        cycle.series.uppercase(),
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                Text(
                                    cycle.price,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    color = DecathlonDarkText
                                )
                            }
                        }

                        // Cycle Details Area
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(cycle.name, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = DecathlonBlue)
                            Text(cycle.description, fontSize = 12.sp, color = Color.DarkGray, lineHeight = 16.sp)
                            
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            // Technical specs summary pill grid
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                AssistChip(
                                    onClick = {},
                                    label = { Text(cycle.gears, fontSize = 10.sp) },
                                    leadingIcon = { Icon(Icons.Default.Settings, contentDescription = "Gears", modifier = Modifier.size(12.dp)) }
                                )
                                AssistChip(
                                    onClick = {},
                                    label = { Text(cycle.frame, fontSize = 10.sp) },
                                    leadingIcon = { Icon(Icons.Default.Architecture, contentDescription = "Frame", modifier = Modifier.size(12.dp)) }
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, "In Stock", tint = DecathlonSuccessGreen, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Decathlon Marina Mall चेन्नई - Available for same day assembly", fontSize = 11.sp, color = DecathlonSuccessGreen, fontWeight = FontWeight.Bold)
                            }
                            
                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = { onNavigateToBook(cycle.name) },
                                colors = ButtonDefaults.buttonColors(containerColor = DecathlonBlue),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Filled.DirectionsBike, "Book")
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Book Assembly & Delivery Now", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// Vector-Drawn High-Fidelity Custom QR Code Component
@Composable
fun SimulatedQrCode(content: String, modifier: Modifier = Modifier) {
    val encodedContent = try {
        java.net.URLEncoder.encode(content, "UTF-8")
    } catch (e: Exception) {
        content
    }
    // High-resolution scannable QR code generation API
    val qrUrl = "https://api.qrserver.com/v1/create-qr-code/?size=350x350&data=$encodedContent&color=007abd"

    var isError by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(true) }

    Box(
        modifier = modifier.background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        coil.compose.AsyncImage(
            model = qrUrl,
            contentDescription = "Decathlon Google Lens Scan QR Code",
            modifier = Modifier.fillMaxSize(),
            onSuccess = {
                isLoading = false
                isError = false
            },
            onError = {
                isError = true
                isLoading = false
            }
        )

        if (isLoading || isError) {
            VectorQrFallback(content = content, modifier = Modifier.fillMaxSize())
            
            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.White.copy(alpha = 0.5f)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        color = Color(0xFF007ABD),
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun VectorQrFallback(content: String, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val sizePx = size.minDimension
        val numModules = 21
        val moduleSize = sizePx / numModules

        // Draw background
        drawRect(Color.White)

        // Corner finder squares
        // Top-Left
        drawFinderPattern(0f, 0f, moduleSize)
        // Top-Right
        drawFinderPattern((numModules - 7) * moduleSize, 0f, moduleSize)
        // Bottom-Left
        drawFinderPattern(0f, (numModules - 7) * moduleSize, moduleSize)

        // Generate deterministic matrix blocks matching content hash
        val hash = content.hashCode()
        val random = java.util.Random(hash.toLong())

        for (row in 0 until numModules) {
            for (col in 0 until numModules) {
                // Skip corner finding pattern areas
                if ((row < 8 && col < 8) ||
                    (row < 8 && col >= numModules - 8) ||
                    (row >= numModules - 8 && col < 8)) {
                    continue
                }
                // Randomly density-fill blocks
                if (random.nextBoolean()) {
                    val blockColor = if (random.nextBoolean()) Color(0xFF007ABD) else Color(0xFF1B2A47)
                    drawRect(
                        color = blockColor,
                        topLeft = androidx.compose.ui.geometry.Offset(col * moduleSize, row * moduleSize),
                        size = androidx.compose.ui.geometry.Size(moduleSize, moduleSize)
                    )
                }
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawFinderPattern(
    x: Float,
    y: Float,
    moduleSize: Float
) {
    // Outer 7x7 square
    drawRect(
        color = Color(0xFF007ABD),
        topLeft = androidx.compose.ui.geometry.Offset(x, y),
        size = androidx.compose.ui.geometry.Size(moduleSize * 7, moduleSize * 7)
    )
    // White 5x5 spacer
    drawRect(
        color = Color.White,
        topLeft = androidx.compose.ui.geometry.Offset(x + moduleSize, y + moduleSize),
        size = androidx.compose.ui.geometry.Size(moduleSize * 5, moduleSize * 5)
    )
    // Inner 3x3 solid block
    drawRect(
        color = Color(0xFF1B2A47),
        topLeft = androidx.compose.ui.geometry.Offset(x + moduleSize * 2, y + moduleSize * 2),
        size = androidx.compose.ui.geometry.Size(moduleSize * 3, moduleSize * 3)
    )
}

// 5. CUSTOMER FEEDBACK BOARD
@Composable
fun FeedbackScreen(viewModel: DeliveryViewModel, feedbackEntries: List<FeedbackEntry>) {
    val scrollState = rememberScrollState()
    val deliveries by viewModel.deliveries.collectAsState()

    // Standalone Feedback form states
    var customName by remember { mutableStateOf("") }
    var customPhone by remember { mutableStateOf("") }
    var customComments by remember { mutableStateOf("") }
    var customRating by remember { mutableStateOf(5.0f) }
    var linkedDeliveryId by remember { mutableStateOf<Int?>(null) }
    var linkedDeliveryOrderId by remember { mutableStateOf<String?>(null) }

    // Dialog trigger states
    var showScannerDialog by remember { mutableStateOf(false) }
    var showQrEnlargedDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Ratings Summary Dashboard Header
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth(),
            border = BorderStroke(1.dp, DecathlonLightGrey),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Customer Experience Index",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = DecathlonBlue
                )
                Spacer(modifier = Modifier.height(12.dp))

                val avg = if (feedbackEntries.isNotEmpty()) feedbackEntries.map { it.rating }.average() else 4.8
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        String.format(Locale.getDefault(), "%.1f", avg),
                        fontWeight = FontWeight.Black,
                        fontSize = 44.sp,
                        color = DecathlonActiveOrange
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        InteractiveStarRatingBar(
                            rating = avg.toFloat(),
                            onRatingChanged = {},
                            enabled = false,
                            starSize = 20.dp
                        )
                        Text(
                            "Based on ${feedbackEntries.size} verified deliveries",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // DECATHLON QR TABLE DESK-TENT PORTAL
        Card(
            colors = CardDefaults.cardColors(containerColor = DecathlonLightBg),
            modifier = Modifier.fillMaxWidth(),
            border = BorderStroke(1.dp, DecathlonLightGrey),
            shape = RoundedCornerShape(20.dp)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(90.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, DecathlonLightGrey, RoundedCornerShape(12.dp))
                        .background(Color.White)
                        .clickable { showQrEnlargedDialog = true }
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    SimulatedQrCode(
                        content = "https://www.google.com/search?sca_esv=5bbf12f94b0d923a&sxsrf=ANbL-n58AW9f6mq8sT7Ih-D9sim-E6FDZw:1781281421595&si=AL3DRZEsmMGCryMMFSHJ3StBhOdZ2-6yYkXd_doETEE1OR-qOZE-CfUeblGLqlUVWdO19yPk2pI6SONlex9_0Ox-Jlnw5TTuJvKt5xYMVuzVBzw5JJ1iI-9jau35e9zyfvn4a54JfAOmryOVhR845LksvkXjh5xqO8cZlPGFRKqz260vbP7i9j0%3D&q=Decathlon+Sports+-+OMR+Marina+Mall+Reviews&sa=X&ved=2ahUKEwif8oOzjoKVAxWBbmwGHYnsH4EQ0bkNegQIOBAH&biw=1536&bih=730&dpr=1.25",
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = DecathlonBlue,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.padding(end = 6.dp)
                        ) {
                            Text(
                                "Live QR Desk-Tent",
                                color = Color.White,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Text("OMR Marina Mall Reviews", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DecathlonDarkText)
                    }
                    Text(
                        "Scan this QR code with Google Lens or your phone's camera to visit the official Google Reviews board for Decathlon Sports - OMR Marina Mall!",
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        color = Color.DarkGray,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Button(
                        onClick = { showScannerDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = DecathlonBlue),
                        contentPadding = PaddingValues(start = 12.dp, top = 6.dp, end = 12.dp, bottom = 6.dp),
                        modifier = Modifier.height(32.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Simulate Store QR Scan", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Direct General Feedback Input Form
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Send Customer Store Review", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DecathlonBlue)
            if (linkedDeliveryOrderId != null) {
                TextButton(onClick = {
                    linkedDeliveryOrderId = null
                    linkedDeliveryId = null
                }) {
                    Text("Clear QR Tag Link", color = Color.Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth(),
            border = BorderStroke(1.dp, DecathlonLightGrey),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (linkedDeliveryOrderId != null) {
                    Surface(
                        color = DecathlonSuccessGreen.copy(alpha = 0.08f),
                        border = BorderStroke(1.dp, DecathlonSuccessGreen.copy(0.3f)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.VerifiedUser, tint = DecathlonSuccessGreen, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text(
                                "Linked Verified Order Purchase ID: #$linkedDeliveryOrderId (Auto-populated via Decathlon QR Scanner)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = DecathlonSuccessGreen
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = customName,
                    onValueChange = { customName = it },
                    label = { Text("Your Full Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = customPhone,
                    onValueChange = { customPhone = it },
                    label = { Text("Customer Contact Mobile") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Rate Decathlon Assembly & Delivery Experience:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                InteractiveStarRatingBar(
                    rating = customRating,
                    onRatingChanged = { customRating = it }
                )
                OutlinedTextField(
                    value = customComments,
                    onValueChange = { customComments = it },
                    label = { Text("Your Message / Suggestion") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (customName.isBlank() || customPhone.isBlank() || customComments.isBlank()) {
                            viewModel.errorToastMessage = "Please fill name, phone, and comments!"
                        } else {
                            viewModel.submitFeedback(
                                customerName = customName,
                                phoneNumber = customPhone,
                                rating = customRating,
                                comment = customComments,
                                deliveryId = linkedDeliveryId,
                                onSuccess = {
                                    customName = ""
                                    customPhone = ""
                                    customComments = ""
                                    customRating = 5.0f
                                    linkedDeliveryId = null
                                    linkedDeliveryOrderId = null
                                }
                            )
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DecathlonBlue),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Submit Customer Feedback", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Live list of submitted feedback entries
        Text("Customer Feedback Logs", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DecathlonBlue)
        Spacer(modifier = Modifier.height(8.dp))

        if (feedbackEntries.isEmpty()) {
            Text("No customer feedback submitted yet.", color = Color.Gray, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
        } else {
            feedbackEntries.forEach { f ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(f.customerName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            InteractiveStarRatingBar(
                                rating = f.rating,
                                onRatingChanged = {},
                                enabled = false,
                                starSize = 14.dp
                            )
                        }
                        Text("Submitted: ${f.date}", fontSize = 10.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(f.comment, fontSize = 12.sp, color = Color.DarkGray)
                        f.deliveryId?.let {
                            Text("Linked Order ID: #DL-$it", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = DecathlonBlue)
                        }
                    }
                }
            }
        }

        // 1. Enlarged QR Code Dialog
        if (showQrEnlargedDialog) {
            Dialog(onDismissRequest = { showQrEnlargedDialog = false }) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.padding(16.dp),
                    elevation = CardDefaults.cardElevation(8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            "OMR Marina Mall Reviews",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            color = DecathlonBlue
                        )
                        Text(
                            "Scan with Google Lens or your camera to inspect or write verified reviews for Decathlon Sports OMR Marina Mall.",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                        )
                        
                        Box(
                            modifier = Modifier
                                .size(220.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .border(1.dp, DecathlonLightGrey)
                                .background(Color.White)
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            SimulatedQrCode(
                                content = "https://www.google.com/search?sca_esv=5bbf12f94b0d923a&sxsrf=ANbL-n58AW9f6mq8sT7Ih-D9sim-E6FDZw:1781281421595&si=AL3DRZEsmMGCryMMFSHJ3StBhOdZ2-6yYkXd_doETEE1OR-qOZE-CfUeblGLqlUVWdO19yPk2pI6SONlex9_0Ox-Jlnw5TTuJvKt5xYMVuzVBzw5JJ1iI-9jau35e9zyfvn4a54JfAOmryOVhR845LksvkXjh5xqO8cZlPGFRKqz260vbP7i9j0%3D&q=Decathlon+Sports+-+OMR+Marina+Mall+Reviews&sa=X&ved=2ahUKEwif8oOzjoKVAxWBbmwGHYnsH4EQ0bkNegQIOBAH&biw=1536&bih=730&dpr=1.25",
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = { showQrEnlargedDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = DecathlonBlue),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Dismiss QR View", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 2. Simulated QR Scanner Camera Dialog
        if (showScannerDialog) {
            val infiniteTransition = rememberInfiniteTransition(label = "Laser")
            val laserOffsetY by infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(2200, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "LaserOffsetY"
            )

            Dialog(onDismissRequest = { showScannerDialog = false }) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)), // Dark camera background
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.padding(8.dp),
                    elevation = CardDefaults.cardElevation(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = DecathlonActiveOrange)
                                Text("Decathlon Live QR Scanner", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                            IconButton(onClick = { showScannerDialog = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.LightGray)
                            }
                        }

                        Text(
                            "Simulating smart camera lens focus. Align barcode or physical cycle tag inside the glowing viewfinder to submit verification feedback:",
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )

                        // Viewed Area with Laser Line
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.Black)
                                .border(2.dp, DecathlonActiveOrange, RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            // Focus frame corner lines
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val w = size.width
                                val h = size.height
                                val lineLen = 30f
                                val strokeW = 4f
                                val orange = Color(0xFFFF5722)

                                // Top Left corner
                                drawLine(orange, androidx.compose.ui.geometry.Offset(10f, 10f), androidx.compose.ui.geometry.Offset(10f + lineLen, 10f), strokeWidth = strokeW)
                                drawLine(orange, androidx.compose.ui.geometry.Offset(10f, 10f), androidx.compose.ui.geometry.Offset(10f, 10f + lineLen), strokeWidth = strokeW)

                                // Top Right corner
                                drawLine(orange, androidx.compose.ui.geometry.Offset(w - 10f, 10f), androidx.compose.ui.geometry.Offset(w - 10f - lineLen, 10f), strokeWidth = strokeW)
                                drawLine(orange, androidx.compose.ui.geometry.Offset(w - 10f, 10f), androidx.compose.ui.geometry.Offset(w - 10f, 10f + lineLen), strokeWidth = strokeW)

                                // Bottom Left corner
                                drawLine(orange, androidx.compose.ui.geometry.Offset(10f, h - 10f), androidx.compose.ui.geometry.Offset(10f + lineLen, h - 10f), strokeWidth = strokeW)
                                drawLine(orange, androidx.compose.ui.geometry.Offset(10f, h - 10f), androidx.compose.ui.geometry.Offset(10f, h - 10f - lineLen), strokeWidth = strokeW)

                                // Bottom Right corner
                                drawLine(orange, androidx.compose.ui.geometry.Offset(w - 10f, h - 10f), androidx.compose.ui.geometry.Offset(w - 10f - lineLen, h - 10f), strokeWidth = strokeW)
                                drawLine(orange, androidx.compose.ui.geometry.Offset(w - 10f, h - 10f), androidx.compose.ui.geometry.Offset(w - 10f, h - 10f - lineLen), strokeWidth = strokeW)
                            }

                            // Moving Laser Sweep
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .fillMaxHeight(0.015f)
                                    .align(Alignment.TopCenter)
                                    .offset(y = 200.dp * laserOffsetY)
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(Color.Transparent, Color(0xFFFF5722), Color.Transparent)
                                        )
                                    )
                            )

                            // Inner scanning target label
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Icon(Icons.Default.QrCode, contentDescription = null, tint = Color.White.copy(0.3f), modifier = Modifier.size(50.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("CAMERA FEED CONNECTED", color = Color.White.copy(0.4f), fontWeight = FontWeight.Bold, fontSize = 9.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Selectable Scannable presets
                        Text("SIMULATED TARGETS TO ALIGN:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.align(Alignment.Start))
                        Spacer(modifier = Modifier.height(6.dp))

                        Column(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 180.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            // Preset 1: General walk-in Chennai tag
                            Card(
                                onClick = {
                                    customName = "Rajesh Ganesan (Walk-in Outlet Customer)"
                                    customPhone = "+91 94445 61280"
                                    customRating = 5.0f
                                    customComments = "Scanned receipt QR. Amazing Decathlon experience here, and very helpful technicians setup my commuter gear."
                                    linkedDeliveryId = null
                                    linkedDeliveryOrderId = "CHENNAI_RETAIL_FAST_PASS"
                                    showScannerDialog = false
                                    viewModel.successToastMessage = "Beep! Rajesh's Retail scan processed!"
                                },
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1F2937)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Storefront, tint = DecathlonActiveOrange, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Column {
                                        Text("Chennai Hub Walk-in tag", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        Text("Pre-populates Rajesh Ganesan Walk-in Feed", color = Color.Gray, fontSize = 9.sp)
                                    }
                                }
                            }

                            // Preset 2: Direct dynamic selection from database deliveries
                            val recentDeliveries = deliveries.take(4)
                            recentDeliveries.forEach { d ->
                                Card(
                                    onClick = {
                                        customName = d.customerName
                                        customPhone = d.phoneNumber
                                        customRating = 5.0f
                                        customComments = "Cycle delivery verification completed. Scanned seat-post tag QR for my ${d.cycleModel}! Assembly is extremely robust."
                                        linkedDeliveryId = d.id
                                        linkedDeliveryOrderId = d.orderId
                                        showScannerDialog = false
                                        viewModel.successToastMessage = "Beep! Order ${d.orderId} receipt tag verified!"
                                    },
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1F2937)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.Default.DirectionsBike, tint = Color(0xFF007ABD), contentDescription = null, modifier = Modifier.size(16.dp))
                                        Column {
                                            Text("Active Order Tag: ${d.orderId}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                            Text("Cust: ${d.customerName} | Cycle: ${d.cycleModel}", color = Color.Gray, fontSize = 9.sp)
                                        }
                                    }
                                }
                            }

                            if (recentDeliveries.isEmpty()) {
                                Text("No recent deliveries available for tagging. Auto-generating a scannable demonstration booking tag...", color = Color.DarkGray, fontSize = 10.sp)
                                Card(
                                    onClick = {
                                        customName = "Anjali Dev (Decathlon Fan)"
                                        customPhone = "+91 98404 99881"
                                        customRating = 5.0f
                                        customComments = "Scanned our delivery rider's badge QR. Incredible speed of Triban dropoff, perfectly packaged!"
                                        linkedDeliveryId = 88
                                        linkedDeliveryOrderId = "DEC-71191-MA"
                                        showScannerDialog = false
                                        viewModel.successToastMessage = "Beep! Verified Decathlon Rider Badge Code!"
                                    },
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1F2937)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.Default.QrCode, tint = Color(0xFF007ABD), contentDescription = null, modifier = Modifier.size(16.dp))
                                        Column {
                                            Text("Demo Tag: Decathlon Rider #88", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                            Text("Pre-populates Customer Anjali Dev", color = Color.Gray, fontSize = 9.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 6. ADMIN LOGIN SCREEN
@Composable
fun AdminLoginScreen(viewModel: DeliveryViewModel, onSuccessfulLogin: () -> Unit) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        DecathlonCycleLogo(modifier = Modifier.size(100.dp), animateSpeedMs = 0)
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            "Admin Center Portal",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 22.sp,
            color = DecathlonBlue
        )
        Text(
            "Access database reports, delivery dispatch registers, and client records securely.",
            textAlign = TextAlign.Center,
            fontSize = 12.sp,
            color = Color.Gray,
            modifier = Modifier.padding(horizontal = 24.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = user,
                    onValueChange = { user = it },
                    label = { Text("Username") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.AccountCircle, contentDescription = "User") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_username_input")
                )

                OutlinedTextField(
                    value = pass,
                    onValueChange = { pass = it },
                    label = { Text("Password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    leadingIcon = { Icon(Icons.Default.Password, contentDescription = "Pass") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_password_input")
                )

                viewModel.loginError?.let { err ->
                    Text(err, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        viewModel.loginAdmin(user, pass, onSuccess = {
                            user = ""
                            pass = ""
                            onSuccessfulLogin()
                        })
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DecathlonBlue),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_submit_login_button")
                ) {
                    Text("Secure Login")
                }
            }
        }


    }
}

// 7. ADMIN DASHBOARD SCREEN
@Composable
fun AdminDashboardScreen(
    viewModel: DeliveryViewModel,
    deliveries: List<Delivery>,
    staffList: List<StaffMember>,
    adminsList: List<Admin>,
    loggedInAdmin: Admin,
    onVerifyOtpFor: (Delivery) -> Unit
) {
    val tabs = remember(loggedInAdmin.isSuperAdmin) {
        if (loggedInAdmin.isSuperAdmin) {
            listOf("Deliveries Log", "Staff Roster", "Admin Accounts", "Cloud Sync")
        } else {
            listOf("Deliveries Log")
        }
    }
    var currentTabIdx by remember { mutableStateOf(0) }

    androidx.compose.runtime.LaunchedEffect(tabs) {
        if (currentTabIdx >= tabs.size) {
            currentTabIdx = 0
        }
    }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        // Automatically sync latest state in background when dashboard is opened to maintain multi-admin consistency
        viewModel.triggerAutoSyncIfNeeded()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        if (tabs.size > 1) {
            TabRow(selectedTabIndex = currentTabIdx, containerColor = Color.White) {
                tabs.forEachIndexed { index, label ->
                    Tab(
                        selected = currentTabIdx == index,
                        onClick = { currentTabIdx = index },
                        text = { Text(label, fontWeight = FontWeight.Bold, fontSize = 11.sp) }
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            val selectedTabLabel = tabs.getOrNull(currentTabIdx) ?: ""
            when (selectedTabLabel) {
                "Deliveries Log" -> DeliveriesLogTab(viewModel, deliveries, onVerifyOtpFor)
                "Staff Roster" -> StaffRosterTab(viewModel, staffList)
                "Admin Accounts" -> SuperAdminAccountsTab(viewModel, adminsList)
                "Cloud Sync" -> CloudSyncTab(viewModel)
            }
        }
    }
}

// 7a. TAB 1: DELIVERIES LOG
@Composable
fun DeliveriesLogTab(
    viewModel: DeliveryViewModel,
    deliveries: List<Delivery>,
    onVerifyOtpFor: (Delivery) -> Unit
) {
    var selectedFilterDate by remember { mutableStateOf("") }
    val context = LocalContext.current
    val calendar = Calendar.getInstance()
    val dpDialog = DatePickerDialog(
        context,
        { _, yr, mo, dy ->
            selectedFilterDate = String.format(Locale.getDefault(), "%04d-%02d-%02d", yr, mo + 1, dy)
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    Column(modifier = Modifier.fillMaxSize()) {
        // Search Delivery Bar
        OutlinedTextField(
            value = viewModel.searchQuery,
            onValueChange = { viewModel.searchQuery = it },
            placeholder = { Text("Search deliveries by ID, customer name, cycle...") },
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
        )

        // Date wise filter selector row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = if (selectedFilterDate.isEmpty()) "All Dates" else selectedFilterDate,
                onValueChange = {},
                readOnly = true,
                label = { Text("Filter Date Scheduled") },
                leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = "Date Filter") },
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (selectedFilterDate.isNotEmpty()) {
                            IconButton(onClick = { selectedFilterDate = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear Date")
                            }
                        }
                        IconButton(onClick = { dpDialog.show() }) {
                            Icon(Icons.Default.DateRange, contentDescription = "Select Date")
                        }
                    }
                },
                modifier = Modifier.weight(1f)
            )
        }

        val finalDeliveries = remember(deliveries, selectedFilterDate) {
            if (selectedFilterDate.isEmpty()) {
                deliveries
            } else {
                deliveries.filter { it.deliveryDate == selectedFilterDate }
            }
        }

        if (finalDeliveries.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No deliveries records match query filters.", color = Color.Gray)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(finalDeliveries) { del ->
                    var isExpandedCard by remember { mutableStateOf(false) }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isExpandedCard = !isExpandedCard }
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            del.orderId,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = DecathlonBlue
                                        )
                                        Surface(
                                            color = Color.LightGray.copy(alpha = 0.4f),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                del.deliveryMethod,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.DarkGray
                                            )
                                        }
                                    }
                                    Text(del.customerName, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                }
                                Surface(
                                    color = when (del.deliveryStatus) {
                                        "Delivered" -> DecathlonSuccessGreen.copy(0.12f)
                                        "Out for Delivery" -> DecathlonActiveOrange.copy(0.12f)
                                        else -> DecathlonBlue.copy(0.12f)
                                    },
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        del.deliveryStatus.uppercase(),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when (del.deliveryStatus) {
                                            "Delivered" -> DecathlonSuccessGreen
                                            "Out for Delivery" -> DecathlonActiveOrange
                                            else -> DecathlonBlue
                                        }
                                    )
                                }
                            }

                            // Expanded administrative edit and status management section
                            if (isExpandedCard) {
                                Spacer(modifier = Modifier.height(12.dp))
                                HorizontalDivider()
                                Spacer(modifier = Modifier.height(12.dp))

                                Text("Cycle Model: ${del.cycleModel}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text("Contact Mobile: ${del.phoneNumber}", fontSize = 12.sp)
                                Text("Delivery Address: ${del.address}", fontSize = 12.sp, color = Color.DarkGray)
                                Text("Schedule Date: ${del.deliveryDate} at ${del.deliveryTime}", fontSize = 12.sp)
                                Text("Allocated Driver: ${del.staffName.ifBlank { "NONE" }}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DecathlonBlue)

                                del.feedbackRating?.let {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Feedback: ", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        InteractiveStarRatingBar(rating = it, onRatingChanged = {}, enabled = false, starSize = 12.dp)
                                        Text(" (${del.feedbackComment})", fontSize = 11.sp, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                HorizontalDivider()
                                Spacer(modifier = Modifier.height(12.dp))

                                // Operations trigger actions
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Set Status selection
                                    var expandedStatusAction by remember { mutableStateOf(false) }
                                    Box {
                                        OutlinedButton(onClick = { expandedStatusAction = true }) {
                                            Text("Set Status", fontSize = 12.sp)
                                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                        }
                                        DropdownMenu(
                                            expanded = expandedStatusAction,
                                            onDismissRequest = { expandedStatusAction = false }
                                        ) {
                                            listOf("Booking", "Booked", "Delivery Person Assigned", "Out for Delivery", "Delivered").forEach { st ->
                                                DropdownMenuItem(
                                                    text = { Text(st) },
                                                    onClick = {
                                                        expandedStatusAction = false
                                                        if (st == "Delivered") {
                                                            // Trigger OTP flow modal validation
                                                            onVerifyOtpFor(del)
                                                        } else {
                                                            viewModel.updateDeliveryDetails(del.copy(deliveryStatus = st), onSuccess = {})
                                                        }
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    // Action buttons
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        if (del.deliveryStatus != "Delivered") {
                                            Button(
                                                onClick = { onVerifyOtpFor(del) },
                                                colors = ButtonDefaults.buttonColors(containerColor = DecathlonActiveOrange)
                                            ) {
                                                Icon(Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Verify OTP", fontSize = 11.sp)
                                            }
                                        }
                                        IconButton(
                                            onClick = { viewModel.deleteDelivery(del) },
                                            colors = IconButtonDefaults.iconButtonColors(contentColor = MaterialTheme.colorScheme.error)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete Order")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 7b. TAB 2: STAFF MANAGEMENT ROSTER
@Composable
fun StaffRosterTab(viewModel: DeliveryViewModel, staffList: List<StaffMember>) {
    var newStaffName by remember { mutableStateOf("") }
    var newStaffPhone by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        // Form to instantly register a staff member
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Register Brand Delivery Driver", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = DecathlonBlue)
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = newStaffName,
                        onValueChange = { newStaffName = it },
                        placeholder = { Text("Staff Full Name") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = newStaffPhone,
                        onValueChange = { newStaffPhone = it },
                        placeholder = { Text("Driver Mobile Phone") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        viewModel.addStaff(newStaffName, newStaffPhone) {
                            newStaffName = ""
                            newStaffPhone = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DecathlonBlue),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Register Driver & Staff Record")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Registered Drivers & Staff Roster", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(8.dp))

        if (staffList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No staff personnel registered yet.", color = Color.Gray)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(staffList) { driver ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(driver.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Contact: ${driver.phone}", fontSize = 12.sp, color = Color.Gray)
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Toggle active state status pill
                                AssistChip(
                                    onClick = {
                                        val nextSt = if (driver.status == "Active") "Resting" else "Active"
                                        viewModel.modifyStaffStatus(driver, nextSt)
                                    },
                                    label = { Text(driver.status, fontSize = 10.sp) },
                                    colors = AssistChipDefaults.assistChipColors(
                                        labelColor = if (driver.status == "Active") DecathlonSuccessGreen else Color.Gray
                                    )
                                )
                                IconButton(
                                    onClick = { viewModel.removeStaff(driver) },
                                    colors = IconButtonDefaults.iconButtonColors(contentColor = MaterialTheme.colorScheme.error)
                                ) {
                                    Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Remove")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 7c. TAB 3: ADMIN ACCOUNTS MANAGER
@Composable
fun SuperAdminAccountsTab(viewModel: DeliveryViewModel, adminsList: List<Admin>) {
    var addAdminUser by remember { mutableStateOf("") }
    var addAdminPass by remember { mutableStateOf("") }
    var addAdminFullName by remember { mutableStateOf("") }
    var addAdminIsSuper by remember { mutableStateOf(false) }

    val loggedInAdmin = viewModel.loggedInAdmin

    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Provision New Administrative Account", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = DecathlonBlue)

                OutlinedTextField(
                    value = addAdminFullName,
                    onValueChange = { addAdminFullName = it },
                    label = { Text("Admin Employee Full Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = addAdminUser,
                        onValueChange = { addAdminUser = it },
                        label = { Text("Username") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = addAdminPass,
                        onValueChange = { addAdminPass = it },
                        label = { Text("Password") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Checkbox(
                        checked = addAdminIsSuper,
                        onCheckedChange = { addAdminIsSuper = it }
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Grant Super Admin Privileges", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }

                Button(
                    onClick = {
                        viewModel.createAdmin(
                            username = addAdminUser,
                            passwordHash = addAdminPass,
                            fullName = addAdminFullName,
                            isSuperAdmin = addAdminIsSuper,
                            onSuccess = {
                                addAdminUser = ""
                                addAdminPass = ""
                                addAdminFullName = ""
                                addAdminIsSuper = false
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DecathlonBlue),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Provision Admin Account")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Registered Database Admins Board", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(8.dp))

        val filteredAdmins = adminsList

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filteredAdmins) { adm ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .padding(12.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(adm.fullName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("User: ${adm.username}", fontSize = 11.sp, color = Color.Gray)
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                color = if (adm.isSuperAdmin) DecathlonActiveOrange.copy(0.12f) else DecathlonBlue.copy(0.12f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    if (adm.isSuperAdmin) "SUPER ADMIN" else "REGULAR ADMIN",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (adm.isSuperAdmin) DecathlonActiveOrange else DecathlonBlue
                                )
                            }
                            if (loggedInAdmin?.isSuperAdmin == true && adm.username != loggedInAdmin?.username) {
                                IconButton(
                                    onClick = { viewModel.deleteAdmin(adm) },
                                    modifier = Modifier.size(32.dp).testTag("delete_admin_${adm.username}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete Admin",
                                        tint = Color.Red,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 7d. TAB 4: CLOUD SYNC CONFIGURATION (MULTI-MOBILE ALIGNMENT)
@Composable
fun CloudSyncTab(viewModel: DeliveryViewModel) {
    var inputUrl by remember { mutableStateOf(viewModel.syncBaseUrl) }
    var inputEnabled by remember { mutableStateOf(viewModel.isSyncEnabled) }
    var inputApiKey by remember { mutableStateOf(viewModel.syncApiKey) }

    LaunchedEffect(viewModel.syncBaseUrl) {
        inputUrl = viewModel.syncBaseUrl
    }
    LaunchedEffect(viewModel.isSyncEnabled) {
        inputEnabled = viewModel.isSyncEnabled
    }
    LaunchedEffect(viewModel.syncApiKey) {
        inputApiKey = viewModel.syncApiKey
    }

    val deliveries by viewModel.deliveries.collectAsState()
    val staffMembers by viewModel.staffMembers.collectAsState()
    val feedbackList by viewModel.feedbackList.collectAsState()
    val adminsList by viewModel.admins.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Architecture & Overview Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DecathlonBlue.copy(0.06f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudQueue,
                            contentDescription = "Cloud Icon",
                            tint = DecathlonBlue,
                            modifier = Modifier.size(28.dp)
                        )
                        Text(
                            "Multi-Device Synchronization Hub",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = DecathlonBlue
                        )
                    }

                    Text(
                        "Connecting multiple mobile devices to a single central backend API and database. Any administrative updates or delivery modifications made on this device are automatically synchronized across all other admin devices.",
                        fontSize = 12.sp,
                        color = Color.DarkGray,
                        lineHeight = 16.sp
                    )

                    // Ascent diagram of multi-admin flow
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White.copy(0.7f), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.PhoneAndroid, "Phone A", tint = DecathlonBlue, modifier = Modifier.size(20.dp))
                                    Text("Admin A", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DecathlonBlue)
                                }
                                Icon(Icons.Default.SyncAlt, "Sync arrow", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Storage, "Central Backend & DB", tint = DecathlonActiveOrange, modifier = Modifier.size(24.dp))
                                    Text("Shared Cloud DB", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, color = DecathlonActiveOrange)
                                }
                                Icon(Icons.Default.SyncAlt, "Sync arrow", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.PhoneAndroid, "Phone B", tint = DecathlonBlue, modifier = Modifier.size(20.dp))
                                    Text("Admin B", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DecathlonBlue)
                                }
                            }
                            Text(
                                "Server endpoint processes atomic list merging for high concurrency resilience.",
                                fontSize = 9.sp,
                                color = Color.Gray,
                                fontStyle = FontStyle.Italic
                            )
                        }
                    }
                }
            }
        }

        // Configuration Settings Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        "Synchronization Parameters",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.Black
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Enable Cloud Sync", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("Automatically trigger updates after changes", fontSize = 11.sp, color = Color.Gray)
                        }
                        Switch(
                            checked = inputEnabled,
                            onCheckedChange = { inputEnabled = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = DecathlonBlue)
                        )
                    }

                    OutlinedTextField(
                        value = inputUrl,
                        onValueChange = { inputUrl = it },
                        label = { Text("Central Backend API Base URL") },
                        placeholder = { Text("https://ais-dev-h52pi5hob4r47xnabsbf4n-867112821624.asia-southeast1.run.app") },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Link, contentDescription = "URL Link", tint = DecathlonBlue) },
                        modifier = Modifier.fillMaxWidth(),
                        supportingText = {
                            Text("Central live database sync endpoint for multi-admin collaboration.", fontSize = 10.sp)
                        }
                    )

                    OutlinedTextField(
                        value = inputApiKey,
                        onValueChange = { inputApiKey = it },
                        label = { Text("Sync Authorization Key (API Key)") },
                        placeholder = { Text("decathlon_sync_key...") },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.VpnKey, contentDescription = "API key", tint = DecathlonBlue) },
                        modifier = Modifier.fillMaxWidth(),
                        supportingText = {
                            Text("Must match JWT/SYNC_API_KEY on server.", fontSize = 10.sp)
                        }
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.updateSyncConfig(inputEnabled, inputUrl, inputApiKey)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DecathlonBlue),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Save Configuration")
                        }

                        if (viewModel.isSyncEnabled) {
                            Button(
                                onClick = {
                                    viewModel.performCloudSync()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DecathlonActiveOrange),
                                enabled = !viewModel.isSyncing,
                                modifier = Modifier.weight(1f)
                            ) {
                                if (viewModel.isSyncing) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                                } else {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Default.Sync, contentDescription = "Sync", modifier = Modifier.size(16.dp))
                                        Text("Force Sync Now")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Real-time synchronization status
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "Local Repository Sync Status",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.Black
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Current Network Settings:", fontSize = 12.sp, color = Color.Gray)
                        Surface(
                            color = if (viewModel.isSyncEnabled) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                if (viewModel.isSyncEnabled) "CLOUD SYNCHRONIZED" else "OFFLINE MODE",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (viewModel.isSyncEnabled) Color(0xFF2E7D32) else Color(0xFFC62828)
                            )
                        }
                    }

                    Divider(color = Color.LightGray.copy(0.5f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (viewModel.lastSyncMessage.contains("Successfully")) Icons.Default.CheckCircle else Icons.Default.Info,
                            contentDescription = "Sync Status Icon",
                            tint = if (viewModel.lastSyncMessage.contains("Successfully")) Color(0xFF2E7D32) else if (viewModel.lastSyncMessage.contains("failed")) Color(0xFFC62828) else Color.Gray,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            viewModel.lastSyncMessage,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.DarkGray
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text("Dataset records stored locally:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DecathlonBlue)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                            Text("${deliveries.size}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                            Text("Deliveries", fontSize = 10.sp, color = Color.Gray)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                            Text("${staffMembers.size}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                            Text("Staff Members", fontSize = 10.sp, color = Color.Gray)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                            Text("${feedbackList.size}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                            Text("Feedbacks", fontSize = 10.sp, color = Color.Gray)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                            Text("${adminsList.size}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                            Text("Admin Users", fontSize = 10.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }

        // Administrative Database Maintenance
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f)),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "Administrative Database Maintenance",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                    Text(
                        "Wipe all local deliveries, registered drivers, and feedback entries to get a fresh start. This deletes all seed/demo information so you can operate with actual details. Default login accounts (Gopal and staff1) are preserved.",
                        fontSize = 11.sp,
                        color = Color.DarkGray,
                        lineHeight = 15.sp
                    )

                    Button(
                        onClick = {
                            viewModel.clearAllLocalDetails()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Demo Details", modifier = Modifier.size(16.dp))
                            Text("Delete All Demo Details", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

// 8. REPORTS & ANALYTICS EXPORT LOG
enum class ReportPeriod(val label: String) {
    ALL_TIME("All Time"),
    DAILY("Daily"),
    WEEKLY("Weekly"),
    MONTHLY("Monthly"),
    YEARLY("Yearly")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(viewModel: DeliveryViewModel, deliveries: List<Delivery>, feedbacks: List<FeedbackEntry>) {
    val context = LocalContext.current
    var isReportVisible by remember { mutableStateOf(false) }
    var generatedReportString by remember { mutableStateOf("") }
    var selectedPeriod by remember { mutableStateOf(ReportPeriod.ALL_TIME) }

    val filteredData = remember(deliveries, feedbacks, selectedPeriod) {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val today = Calendar.getInstance()
        today.set(Calendar.HOUR_OF_DAY, 0)
        today.set(Calendar.MINUTE, 0)
        today.set(Calendar.SECOND, 0)
        today.set(Calendar.MILLISECOND, 0)

        val todayTime = today.timeInMillis
        val oneDayMs = 24 * 60 * 60 * 1000L

        val filtered = deliveries.filter { del ->
            try {
                val delDate = sdf.parse(del.deliveryDate)
                if (delDate != null) {
                    val diffMs = todayTime - delDate.time
                    when (selectedPeriod) {
                        ReportPeriod.DAILY -> {
                            val delCal = Calendar.getInstance().apply { time = delDate }
                            delCal.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
                            delCal.get(Calendar.MONTH) == today.get(Calendar.MONTH) &&
                            delCal.get(Calendar.DAY_OF_MONTH) == today.get(Calendar.DAY_OF_MONTH)
                        }
                        ReportPeriod.WEEKLY -> {
                            diffMs <= 7 * oneDayMs && diffMs >= -oneDayMs
                        }
                        ReportPeriod.MONTHLY -> {
                            diffMs <= 30 * oneDayMs && diffMs >= -oneDayMs
                        }
                        ReportPeriod.YEARLY -> {
                            diffMs <= 365 * oneDayMs && diffMs >= -oneDayMs
                        }
                        ReportPeriod.ALL_TIME -> true
                    }
                } else {
                    selectedPeriod == ReportPeriod.ALL_TIME
                }
            } catch (e: Exception) {
                selectedPeriod == ReportPeriod.ALL_TIME
            }
        }
        
        val filteredIds = filtered.map { it.id }.toSet()
        val filteredFeedbacks = feedbacks.filter { f ->
            filteredIds.contains(f.deliveryId)
        }

        Pair(filtered, filteredFeedbacks)
    }

    val (reportDeliveries, reportFeedbacks) = filteredData

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Selection of daily, weekly, monthly, yearly
        Text(
            "Select Reporting Interval",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = DecathlonBlue,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ReportPeriod.values().forEach { period ->
                FilterChip(
                    selected = selectedPeriod == period,
                    onClick = { selectedPeriod = period },
                    label = { Text(period.label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = DecathlonBlue,
                        selectedLabelColor = Color.White,
                        containerColor = Color.White,
                        labelColor = Color.Gray
                    ),
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (selectedPeriod == period) DecathlonBlue else DecathlonLightGrey
                    )
                )
            }
        }

        // Analytics breakdown dashboard
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("${selectedPeriod.label} Performance Metrics", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = DecathlonBlue)
                Spacer(modifier = Modifier.height(16.dp))

                val total = reportDeliveries.size
                val booking = reportDeliveries.count { it.deliveryStatus == "Booking" }
                val booked = reportDeliveries.count { it.deliveryStatus == "Booked" }
                val transit = reportDeliveries.count { it.deliveryStatus == "Out for Delivery" }
                val delivered = reportDeliveries.count { it.deliveryStatus == "Delivered" }

                // Live Progress bars
                CircularProgressRow(label = "Booking State (Pending)", count = booking, total = total, color = Color.LightGray)
                CircularProgressRow(label = "Booked", count = booked, total = total, color = DecathlonBlue)
                CircularProgressRow(label = "In Transit Rig", count = transit, total = total, color = DecathlonActiveOrange)
                CircularProgressRow(label = "Delivered (Completed)", count = delivered, total = total, color = DecathlonSuccessGreen)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Trigger PDF & Excel Report downloads, and Share details
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth(),
            border = BorderStroke(1.dp, DecathlonLightGrey),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(DecathlonActiveOrange.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PictureAsPdf, tint = DecathlonActiveOrange, contentDescription = "PDF", modifier = Modifier.size(32.dp))
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    "Compile and Export Records",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp,
                    color = DecathlonDarkText
                )
                Text(
                    "Generate and download official PDF audits, spreadsheet-compatible Excel logs (CSV), or instantly share live delivery manifests.",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))

                // PDF compiling block
                val buildReportString = {
                    val sb = java.lang.StringBuilder()
                    sb.append("=========================================\n")
                    sb.append("      DECATHLON CYCLE DELIVERY REPORT    \n")
                    sb.append("       Marina Mall Center - Chennai     \n")
                    sb.append("            Period: ${selectedPeriod.label.uppercase()} \n")
                    sb.append("=========================================\n")
                    sb.append("Generated Time: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}\n")
                    sb.append("Total Deliveries Recorded: ${reportDeliveries.size}\n")
                    sb.append("Completed Deliveries: ${reportDeliveries.count { it.deliveryStatus == "Delivered" }}\n")
                    sb.append("Average Feedback Index: ${if (reportFeedbacks.isNotEmpty()) reportFeedbacks.map { it.rating }.average() else 4.8}\n")
                    sb.append("-----------------------------------------\n\n")

                    sb.append("LIVE ORDER RECORDS:\n")
                    reportDeliveries.forEachIndexed { idx, d ->
                        sb.append("${idx + 1}. [${d.orderId}] - CUST: ${d.customerName} | ${d.phoneNumber}\n")
                        sb.append("   - CYCLE: ${d.cycleModel} | DRIVER: ${d.staffName}\n")
                        sb.append("   - STATUS: ${d.deliveryStatus} | OTP Code: ${d.otp} (Verified: ${d.otpVerified})\n")
                        d.feedbackComment?.let {
                            sb.append("   - CUSTOMER COMMENT: \"$it\" (${d.feedbackRating} Stars)\n")
                        }
                        sb.append("\n")
                    }
                    sb.append("=========================================\n")
                    sb.append("     END OF STATEMENT AUDIT RECORD       \n")
                    sb.append("=========================================\n")
                    sb.toString()
                }

                // 1. PDF DOWNLOAD BUTTON
                Button(
                    onClick = {
                        val file = ReportExporter.exportToPdf(context, reportDeliveries, reportFeedbacks)
                        if (file != null) {
                            generatedReportString = buildReportString()
                            isReportVisible = true
                            viewModel.successToastMessage = "${selectedPeriod.label} PDF Report downloaded: Documents/${file.name}"
                        } else {
                            viewModel.errorToastMessage = "Failed to compile PDF Report"
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DecathlonBlue),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Download ${selectedPeriod.label} Report (PDF)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                // 2. EXCEL DOWNLOAD BUTTON
                Button(
                    onClick = {
                        val file = ReportExporter.exportToExcel(context, reportDeliveries)
                        if (file != null) {
                            generatedReportString = buildReportString()
                            isReportVisible = true
                            viewModel.successToastMessage = "Excel sheet downloaded: Documents/${file.name}"
                        } else {
                            viewModel.errorToastMessage = "Failed to export Excel (CSV)"
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DecathlonSuccessGreen),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Assessment, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Download Excel Log (CSV)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                // 3. SHARE COMPILATION & SHARE DETAILS BUTTONS IN A ROW
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Share native files
                    OutlinedButton(
                        onClick = {
                            val pdfFile = ReportExporter.exportToPdf(context, reportDeliveries, reportFeedbacks)
                            if (pdfFile != null) {
                                ReportExporter.shareFile(context, pdfFile, "application/pdf")
                            } else {
                                viewModel.errorToastMessage = "Failed to generate file for sharing"
                            }
                        },
                        modifier = Modifier.weight(1f),
                        border = BorderStroke(1.dp, DecathlonBlue),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, tint = DecathlonBlue, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share PDF", color = DecathlonBlue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    // Share Text details
                    OutlinedButton(
                        onClick = {
                            val textData = buildReportString()
                            ReportExporter.shareTextDetails(context, textData)
                        },
                        modifier = Modifier.weight(1f),
                        border = BorderStroke(1.dp, DecathlonBlue),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, tint = DecathlonBlue, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share Text", color = DecathlonBlue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        if (isReportVisible) {
            Spacer(modifier = Modifier.height(16.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color.LightGray),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Audit Raw Document View", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DecathlonBlue)
                        IconButton(onClick = { isReportVisible = false }) {
                            Icon(Icons.Default.DisabledByDefault, "Close")
                        }
                    }
                    Text(
                        text = generatedReportString,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = Color.DarkGray,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DecathlonLightBg)
                            .padding(12.dp)
                            .horizontalScroll(rememberScrollState())
                    )
                }
            }
        }
    }
}

@Composable
fun CircularProgressRow(label: String, count: Int, total: Int, color: Color) {
    val progress = if (total > 0) count.toFloat() / total.toFloat() else 0f
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("$count out of $total orders (${String.format(Locale.getDefault(), "%.1f", progress * 100)}%)", fontSize = 11.sp, color = Color.Gray)
        }
        CircularProgressIndicator(
            progress = progress,
            color = color,
            trackColor = Color.LightGray.copy(0.3f),
            strokeWidth = 6.dp,
            modifier = Modifier.size(36.dp)
        )
    }
}

// 9. ABOUT PAGE
@Composable
fun AboutScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                DecathlonCycleLogo(modifier = Modifier.size(110.dp), animateSpeedMs = 5000)
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    "Decathlon Marina Mall",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp,
                    color = DecathlonBlue
                )
                Text(
                    "Ground Floor Flagship Store",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = DecathlonActiveOrange
                )

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Default.Call, tint = DecathlonBlue, contentDescription = "Call")
                    Column {
                        Text("Telephone Hotline", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("+91 8939796182", fontSize = 13.sp, color = Color.DarkGray)
                        Text("Direct order status helpline and pre-dispatch assembly desk.", fontSize = 10.sp, color = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Default.Language, tint = DecathlonBlue, contentDescription = "Website")
                    Column {
                        Text("Digital Store Website", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Decathlon Marina Mall, OMR Chennai", fontSize = 13.sp, color = Color.DarkGray)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Default.Map, tint = DecathlonBlue, contentDescription = "Map")
                    Column {
                        Text("Physical Logistics Center", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "Ground floor, Marina Mall,\nNo. 28, Rajiv Gandhi Salai (OMR),\nnear Dell Store,\nEgattur, Chennai,\nTamil Nadu - 603103",
                            fontSize = 12.sp,
                            color = Color.DarkGray,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }



        Spacer(modifier = Modifier.height(24.dp))

        // Sports message visual banner
        Text(
            "SPORT FOR ALL | ALL FOR SPORT",
            fontWeight = FontWeight.Black,
            fontSize = 13.sp,
            color = Color.Gray
        )
    }
}

// ==========================================
// DYNAMIC PHOTO OR VECTOR LOGO RENDERER
// ==========================================
@Composable
fun DeliveryPhotoRepresentation(
    photoUri: String?,
    cycleModel: String,
    modifier: Modifier = Modifier,
    size: androidx.compose.ui.unit.Dp = 48.dp
) {
    if (!photoUri.isNullOrBlank() && (
        photoUri.startsWith("content://") || 
        photoUri.startsWith("file://") || 
        photoUri.startsWith("/uploads/") || 
        photoUri.startsWith("http://") || 
        photoUri.startsWith("https://") ||
        photoUri.startsWith("data:")
    )) {
        Box(
            modifier = modifier
                .size(size)
                .clip(RoundedCornerShape(12.dp))
                .background(DecathlonLightBg),
            contentAlignment = Alignment.Center
        ) {
            coil.compose.AsyncImage(
                model = photoUri,
                contentDescription = "Cycle Photo",
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                error = androidx.compose.ui.res.painterResource(android.R.drawable.ic_menu_gallery)
            )
        }
    } else {
        Box(
            modifier = modifier
                .size(size)
                .clip(RoundedCornerShape(12.dp))
                .background(DecathlonLightBg),
            contentAlignment = Alignment.Center
        ) {
            val accentColor = CycleCatalog.items.firstOrNull { it.name == cycleModel }?.accentColor ?: DecathlonBlue
            DecathlonCycleLogo(primaryColor = accentColor, modifier = Modifier.fillMaxSize())
        }
    }
}
