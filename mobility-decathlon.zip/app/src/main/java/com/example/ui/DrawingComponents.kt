package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.DecathlonActiveOrange
import com.example.ui.theme.DecathlonBlue

@Composable
fun DecathlonCycleLogo(
    modifier: Modifier = Modifier,
    primaryColor: Color = DecathlonBlue,
    secondaryColor: Color = DecathlonActiveOrange,
    animateSpeedMs: Int = 0
) {
    // Optional wheel rotation animation
    val infiniteTransition = rememberInfiniteTransition(label = "bike_rotation")
    val rotationAngle by if (animateSpeedMs > 0) {
        infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = FairingEasing(animateSpeedMs),
                repeatMode = RepeatMode.Restart
            ),
            label = "wheel_spin"
        )
    } else {
        remember { mutableStateOf(0f) }
    }

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        
        val strokeWidthVal = width * 0.05f
        val wheelRadius = width * 0.22f
        val lineStroke = Stroke(width = strokeWidthVal, cap = StrokeCap.Round)

        // Wheels positions
        val leftWheelCenter = Offset(width * 0.25f, height * 0.70f)
        val rightWheelCenter = Offset(width * 0.75f, height * 0.70f)

        // Draw Wheels Tires
        drawCircle(
            color = Color(0xFF1E2E3E),
            radius = wheelRadius,
            center = leftWheelCenter,
            style = Stroke(width = strokeWidthVal * 1.5f)
        )
        drawCircle(
            color = primaryColor,
            radius = wheelRadius * 0.75f,
            center = leftWheelCenter,
            style = Stroke(width = strokeWidthVal * 0.6f)
        )
        drawCircle(
            color = Color(0xFF1E2E3E),
            radius = wheelRadius,
            center = rightWheelCenter,
            style = Stroke(width = strokeWidthVal * 1.5f)
        )
        drawCircle(
            color = primaryColor,
            radius = wheelRadius * 0.75f,
            center = rightWheelCenter,
            style = Stroke(width = strokeWidthVal * 0.6f)
        )

        // Inner Wheel Spokes
        val spokeCount = 6
        for (i in 0 until spokeCount) {
            val angleRad = Math.toRadians((i * (360f / spokeCount) + rotationAngle).toDouble())
            val dx = (wheelRadius * Math.cos(angleRad)).toFloat()
            val dy = (wheelRadius * Math.sin(angleRad)).toFloat()
            
            drawLine(
                color = Color.LightGray,
                start = leftWheelCenter,
                end = Offset(leftWheelCenter.x + dx, leftWheelCenter.y + dy),
                strokeWidth = strokeWidthVal * 0.25f
            )
            drawLine(
                color = Color.LightGray,
                start = rightWheelCenter,
                end = Offset(rightWheelCenter.x + dx, rightWheelCenter.y + dy),
                strokeWidth = strokeWidthVal * 0.25f
            )
        }

        // Frame Joins / Bottom Bracket (BB)
        val bottomBracket = Offset(width * 0.46f, height * 0.70f)
        val seatPostJunction = Offset(width * 0.40f, height * 0.38f)
        val headTubeJunction = Offset(width * 0.64f, height * 0.32f)

        // Draw Frame Tubes (Main Sport Triangles)
        val frameBrush = Brush.linearGradient(colors = listOf(primaryColor, secondaryColor))
        
        // Rear stay triangle (Rear Axel -> Seat Junc, Rear Axel -> BB, BB -> Seat Junc)
        drawLine(brush = frameBrush, start = leftWheelCenter, end = seatPostJunction, strokeWidth = strokeWidthVal, cap = StrokeCap.Round)
        drawLine(brush = frameBrush, start = leftWheelCenter, end = bottomBracket, strokeWidth = strokeWidthVal, cap = StrokeCap.Round)
        drawLine(brush = frameBrush, start = bottomBracket, end = seatPostJunction, strokeWidth = strokeWidthVal, cap = StrokeCap.Round)

        // Front triangle (BB -> Head, Seat -> Head)
        drawLine(brush = frameBrush, start = bottomBracket, end = headTubeJunction, strokeWidth = strokeWidthVal, cap = StrokeCap.Round)
        drawLine(brush = frameBrush, start = seatPostJunction, end = headTubeJunction, strokeWidth = strokeWidthVal, cap = StrokeCap.Round)

        // Front forks (Head Junc -> Front Axel)
        drawLine(color = Color(0xFF1E2E3E), start = headTubeJunction, end = rightWheelCenter, strokeWidth = strokeWidthVal, cap = StrokeCap.Round)

        // Seat Tube Extension and Saddle
        val saddleCenter = Offset(seatPostJunction.x - width * 0.02f, seatPostJunction.y - height * 0.08f)
        drawLine(color = Color(0xFF1E2E3E), start = seatPostJunction, end = saddleCenter, strokeWidth = strokeWidthVal * 0.8f, cap = StrokeCap.Round)
        // Saddle design
        drawLine(
            color = Color(0xFF0F2537),
            start = Offset(saddleCenter.x - width * 0.08f, saddleCenter.y),
            end = Offset(saddleCenter.x + width * 0.06f, saddleCenter.y + height * 0.02f),
            strokeWidth = strokeWidthVal * 1.5f,
            cap = StrokeCap.Round
        )

        // Handlebars (Head Tube Extension and Bars)
        val handlePost = Offset(headTubeJunction.x + width * 0.02f, headTubeJunction.y - height * 0.12f)
        drawLine(color = Color(0xFF1E2E3E), start = headTubeJunction, end = handlePost, strokeWidth = strokeWidthVal * 0.8f, cap = StrokeCap.Round)
        // Curved Bars
        drawLine(
            color = Color(0xFF0F2537),
            start = Offset(handlePost.x - width * 0.04f, handlePost.y),
            end = Offset(handlePost.x + width * 0.04f, handlePost.y - height * 0.02f),
            strokeWidth = strokeWidthVal * 1.25f,
            cap = StrokeCap.Round
        )

        // Chainring / Chain visual
        drawCircle(
            color = secondaryColor,
            radius = wheelRadius * 0.28f,
            center = bottomBracket,
            style = Stroke(width = strokeWidthVal * 0.6f)
        )
        drawCircle(
            color = Color(0xFF1E2E3E),
            radius = wheelRadius * 0.12f,
            center = bottomBracket
        )
    }
}

@Composable
fun InteractiveStarRatingBar(
    rating: Float,
    onRatingChanged: (Float) -> Unit,
    modifier: Modifier = Modifier,
    starSize: Dp = 32.dp,
    enabled: Boolean = true
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 1..5) {
            val filled = i <= rating
            Icon(
                imageVector = if (filled) Icons.Filled.Star else Icons.Outlined.Star,
                contentDescription = "Star $i",
                tint = if (filled) DecathlonActiveOrange else Color.Gray,
                modifier = Modifier
                    .size(starSize)
                    .clickable(enabled = enabled) {
                        onRatingChanged(i.toFloat())
                    }
            )
        }
    }
}

private fun FairingEasing(durationMs: Int): TweenSpec<Float> {
    return tween(durationMs, easing = LinearEasing)
}
