package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DecathlonBlue = Color(0xFF007ABD)
val DecathlonActiveOrange = Color(0xFFFF8F00)
val DecathlonDarkPrimary = Color(0xFF005C8D)
val DecathlonLightBg = Color(0xFFF8FAFC)
val DecathlonCardWhite = Color(0xFFFFFFFF)
val DecathlonDarkText = Color(0xFF0F172A)
val DecathlonLightGrey = Color(0xFFF1F5F9)
val DecathlonSuccessGreen = Color(0xFF059669) // Emerald-600 from design
val DecathlonWarningAmber = Color(0xFFD97706) // Amber-600
val DecathlonInfoBlue = Color(0xFF0288D1)
