package com.example.ui

import androidx.compose.ui.graphics.Color

data class DecathlonCycle(
    val id: String,
    val name: String,
    val series: String, // Rockrider, Triban, Riverside
    val category: String, // Mountain, Road, Hybrid
    val price: String,
    val description: String,
    val gears: String,
    val frame: String,
    val brakes: String,
    val accentColor: Color,
    val presetPhotoId: String // used as the preset tag (e.g. preset_rockrider)
)

object CycleCatalog {
    val items = listOf(
        // B'Twin Classic Series
        DecathlonCycle(
            id = "BT_MYBIKE",
            name = "B'Twin My Bike",
            series = "B'Twin",
            category = "City",
            price = "₹7,999",
            description = "A simple, light, and low-maintenance multi-utility city cycle. Robust steel frame built for daily commutes.",
            gears = "Single Speed",
            frame = "Solid Steel Commuter Frame",
            brakes = "Caliper Brakes",
            accentColor = Color(0xFF555555),
            presetPhotoId = "preset_btwin_mybike"
        ),
        DecathlonCycle(
            id = "BT_RR340",
            name = "B'Twin Rockrider 340",
            series = "Rockrider",
            category = "Mountain",
            price = "₹12,499",
            description = "A versatile sport-recreation mountain bike with responsive front suspension forks and ergonomic frame geometry.",
            gears = "21-Speed Shimano Tourney",
            frame = "6061 Sport Aluminum Frame",
            brakes = "V-Brakes",
            accentColor = Color(0xFFFF5722),
            presetPhotoId = "preset_btwin_rr340"
        ),

        // Rockrider Mountain Series
        DecathlonCycle(
            id = "RR30",
            name = "Rockrider ST 30",
            series = "Rockrider",
            category = "Mountain",
            price = "₹10,999",
            description = "The ultimate entry-level recreational mountain bike, designed for park paths and occasional trail excursions.",
            gears = "7-Speed Microshift",
            frame = "Hi-Ten Steel Frame",
            brakes = "Reliable V-Brakes",
            accentColor = Color(0xFFC62828),
            presetPhotoId = "preset_rockrider_st30"
        ),
        DecathlonCycle(
            id = "RR120",
            name = "Rockrider ST 120",
            series = "Rockrider",
            category = "Mountain",
            price = "₹17,999",
            description = "Vibrant sporty trail explorer featuring a progressive geometry, single chainring simplicity, and double wall rims.",
            gears = "9-Speed 1x Single Chainring",
            frame = "Lightweight 6061 Aluminum",
            brakes = "Tektro Mechanical Disc Brakes",
            accentColor = Color(0xFFEF6C00),
            presetPhotoId = "preset_rockrider"
        ),
        DecathlonCycle(
            id = "RR540",
            name = "Rockrider ST 540",
            series = "Rockrider",
            category = "Mountain",
            price = "₹34,999",
            description = "High-performance trail machine engineered with responsive front hydraulic forks and double hydraulic disc brakes.",
            gears = "18-Speed Shimano Altus",
            frame = "Tapered Aluminum Trail Frame",
            brakes = "Hydraulic Disc Brakes",
            accentColor = Color(0xFF1565C0),
            presetPhotoId = "preset_rockrider_st540"
        ),
        DecathlonCycle(
            id = "RR_XC100",
            name = "Rockrider XC 100",
            series = "Rockrider",
            category = "Mountain",
            price = "₹69,999",
            description = "High-performance cross-country race bike with Manitou air-spring forks and broad gearing range.",
            gears = "12-Speed SRAM SX Eagle",
            frame = "Ultralight Triple Butted XC Alloy",
            brakes = "SRAM Level Hydraulic Disc",
            accentColor = Color(0xFF2E7D32),
            presetPhotoId = "preset_rockrider_xc100"
        ),

        // Triban Road Series
        DecathlonCycle(
            id = "TB100",
            name = "Triban RC 100",
            series = "Triban",
            category = "Road",
            price = "₹22,999",
            description = "Beginner's road bike with extremely intuitive gear changes and versatile hybrid tires for light paved path utility.",
            gears = "7-Speed Shimano Tourney",
            frame = "6061 Sloping Alloy Frame",
            brakes = "Promax Caliper Brakes",
            accentColor = Color(0xFF6A1B29),
            presetPhotoId = "preset_triban_rc100"
        ),
        DecathlonCycle(
            id = "TB120",
            name = "Triban RC 120",
            series = "Triban",
            category = "Road",
            price = "₹29,999",
            description = "The ideal beginner endurance road bike. Comfort-focused carbon fork blade inserts and supportive saddle.",
            gears = "16-Speed Microshift Road",
            frame = "6061 Comfort Aluminum",
            brakes = "Dual mechanical disc brakes",
            accentColor = Color(0xFF00695C),
            presetPhotoId = "preset_triban"
        ),
        DecathlonCycle(
            id = "TB500",
            name = "Triban RC 500",
            series = "Triban",
            category = "Road",
            price = "₹49,999",
            description = "A classic endurance road and light gravel cruiser. Seamless shifting and generous clearance for wide tires.",
            gears = "18-Speed Shimano Sora R3000",
            frame = "Evo Comfort Carbon/Alloy",
            brakes = "Microshift Mechanical Disc",
            accentColor = Color(0xFF37474F),
            presetPhotoId = "preset_triban_rc500"
        ),
        DecathlonCycle(
            id = "TB520",
            name = "Triban RC 520",
            series = "Triban",
            category = "Road",
            price = "₹74,999",
            description = "High-end amateur sportive road bike equipped with full premium Shimano 105 drivetrain and hydro-mech brakes.",
            gears = "22-Speed Shimano 105 R7000",
            frame = "Pro Comfort Endurance Alloy",
            brakes = "TRP HY/RD Hybrid Hydraulic",
            accentColor = Color(0xFFD84315),
            presetPhotoId = "preset_triban_rc520"
        ),
        DecathlonCycle(
            id = "TB_GRVL120",
            name = "Triban GRVL 120",
            series = "Triban",
            category = "Gravel",
            price = "₹37,999",
            description = "Specifically designed gravel adventure build featuring flared handlerbars and high friction gravel tires.",
            gears = "10-Speed Microshift Advent X",
            frame = "Reinforced Comfort Gravel Alloy",
            brakes = "Promax Mechanical Disc",
            accentColor = Color(0xFF827717),
            presetPhotoId = "preset_triban_grvl120"
        ),

        // Riverside Hybrid Series
        DecathlonCycle(
            id = "RS100",
            name = "Riverside 100",
            series = "Riverside",
            category = "Hybrid",
            price = "₹9,999",
            description = "Uncomplicated commuter hybrid cycle for easy recreation, park routes and smooth village paths.",
            gears = "6-Speed B'Twin Grip-Shift",
            frame = "Relaxed Hi-Ten Steel Frame",
            brakes = "V-Brakes",
            accentColor = Color(0xFF303F9F),
            presetPhotoId = "preset_riverside_100"
        ),
        DecathlonCycle(
            id = "RS120",
            name = "Riverside 120",
            series = "Riverside",
            category = "Hybrid",
            price = "₹12,499",
            description = "A clean dual-purpose hybrid ready for quiet neighborhood paved tracks or weekend canal towpath loops.",
            gears = "8-Speed Grip-Shift",
            frame = "Low-Step Ergonomic Steel",
            brakes = "V-Brakes with alloy levers",
            accentColor = Color(0xFF43A047),
            presetPhotoId = "preset_riverside_120"
        ),
        DecathlonCycle(
            id = "RS500",
            name = "Riverside 500",
            series = "Riverside",
            category = "Hybrid",
            price = "₹22,999",
            description = "Athletic trekking machine with suspension forks, highly breathable sport saddle, and puncture-resistant tires.",
            gears = "9-Speed Shimano Altus Trigger",
            frame = "Ultralight Ergonomic Aluminum",
            brakes = "B’Twin Hydraulic Disc Brakes",
            accentColor = Color(0xFF0082C3),
            presetPhotoId = "preset_riverside"
        ),
        DecathlonCycle(
            id = "RS900",
            name = "Riverside 900",
            series = "Riverside",
            category = "Hybrid",
            price = "₹39,999",
            description = "Ultimate multi-terrain cruiser. Lockout mineral grease front suspension, and deep profile performance tires.",
            gears = "10-Speed Shimano Deore 1x10",
            frame = "Multi-butted Performance Alloy",
            brakes = "Tektro Hydraulic Disc Brakes",
            accentColor = Color(0xFF4E342E),
            presetPhotoId = "preset_riverside_900"
        ),

        // Elops City & Urban Series
        DecathlonCycle(
            id = "EL_SS500",
            name = "Elops Single Speed 500",
            series = "Elops",
            category = "City",
            price = "₹14,999",
            description = "Chic, lightweight fixie-style single speed urban machine. Agile handling for fast city maneuverability.",
            gears = "Single Speed with Flip-Flop Hub",
            frame = "Hi-Ten Sport Steel Frame",
            brakes = "Dual Caliper Road Brakes",
            accentColor = Color(0xFF00ACC1),
            presetPhotoId = "preset_elops_ss500"
        ),
        DecathlonCycle(
            id = "EL_LD500",
            name = "Elops LD 500",
            series = "Elops",
            category = "City",
            price = "₹24,999",
            description = "Designed for fast daily commutes. Lightweight frame, thin rolling tires, and integrated dynamo lights.",
            gears = "9-Speed SRAM X4",
            frame = "Double Butted Aluminum Frame",
            brakes = "Mechanical Disc Brakes",
            accentColor = Color(0xFFFDD835),
            presetPhotoId = "preset_elops_ld500"
        ),

        // Van Rysel Premium Racer Series
        DecathlonCycle(
            id = "VR_NCR_CF",
            name = "Van Rysel NCR CF Shimano 105",
            series = "Van Rysel",
            category = "Road",
            price = "₹1,49,999",
            description = "Premium carbon frame sportive road racer. Outstanding stiffness, response and lightweight construction.",
            gears = "22-Speed Shimano 105 R7000",
            frame = "Van Rysel High Modulus Carbon",
            brakes = "Shimano 105 Hydraulic Disc",
            accentColor = Color(0xFF263238),
            presetPhotoId = "preset_vanrysel_ncr"
        ),
        DecathlonCycle(
            id = "VR_RCR_PRO",
            name = "Van Rysel RCR Pro Dura-Ace",
            series = "Van Rysel",
            category = "Road",
            price = "₹3,99,999",
            description = "Elite UCI professional race machine. Optimized aerodynamically in wind tunnels for uncompromising velocity.",
            gears = "24-Speed Shimano Dura-Ace Di2",
            frame = "Ultra-lightweight HM Pro Carbon",
            brakes = "Dura-Ace Hydraulic Disc",
            accentColor = Color(0xFF1E88E5),
            presetPhotoId = "preset_vanrysel_rcr_pro"
        )
    )

    fun getPresetLabel(presetId: String?): String {
        return items.firstOrNull { it.presetPhotoId == presetId }?.name ?: "Custom Photo File"
    }
}
