package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "deliveries")
data class Delivery(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val customerName: String,
    val phoneNumber: String,
    val cycleModel: String,
    val orderId: String,
    val address: String,
    val deliveryDate: String,
    val deliveryTime: String,
    val photoUri: String? = null,
    val staffName: String = "",
    val deliveryStatus: String = "Booking", // Booking -> Booked -> Delivery Person Assigned -> Out for Delivery -> Delivered
    val deliveryMethod: String = "Store Delivery", // ACE Order, Customer Pickup, Store Delivery
    val otp: String = "",
    val otpVerified: Boolean = false,
    val feedbackRating: Float? = null,
    val feedbackComment: String? = null,
    val deliveryCompletedTime: String? = null,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "admins")
data class Admin(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val username: String,
    val passwordHash: String,
    val fullName: String,
    val isSuperAdmin: Boolean = false
) : Serializable

@Entity(tableName = "staff")
data class StaffMember(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val phone: String,
    val status: String = "Active" // Active, Hand-off, On Delivery, Resting
) : Serializable

@Entity(tableName = "feedback")
data class FeedbackEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val customerName: String,
    val phoneNumber: String,
    val rating: Float,
    val comment: String,
    val date: String,
    val deliveryId: Int? = null
) : Serializable
