package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DeliveryDao {
    @Query("SELECT * FROM deliveries ORDER BY timestamp DESC")
    fun getAllDeliveries(): Flow<List<Delivery>>

    @Query("SELECT * FROM deliveries WHERE id = :id")
    fun getDeliveryByIdFlow(id: Int): Flow<Delivery?>

    @Query("SELECT * FROM deliveries WHERE id = :id")
    suspend fun getDeliveryById(id: Int): Delivery?

    @Query("SELECT * FROM deliveries WHERE orderId = :orderId")
    suspend fun getDeliveryByOrderId(orderId: String): Delivery?

    @Query("SELECT * FROM deliveries WHERE customerName LIKE '%' || :query || '%' OR orderId LIKE '%' || :query || '%' OR phoneNumber LIKE '%' || :query || '%' OR cycleModel LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchDeliveries(query: String): Flow<List<Delivery>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDelivery(delivery: Delivery): Long

    @Update
    suspend fun updateDelivery(delivery: Delivery)

    @Delete
    suspend fun deleteDelivery(delivery: Delivery)

    @Query("DELETE FROM deliveries")
    suspend fun deleteAllDeliveries()
}

@Dao
interface AdminDao {
    @Query("SELECT * FROM admins ORDER BY id ASC")
    fun getAllAdmins(): Flow<List<Admin>>

    @Query("SELECT * FROM admins WHERE username = :username LIMIT 1")
    suspend fun getAdminByUsername(username: String): Admin?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdmin(admin: Admin): Long

    @Delete
    suspend fun deleteAdmin(admin: Admin)
}

@Dao
interface StaffDao {
    @Query("SELECT * FROM staff ORDER BY name ASC")
    fun getAllStaff(): Flow<List<StaffMember>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStaff(staff: StaffMember): Long

    @Update
    suspend fun updateStaff(staff: StaffMember)

    @Delete
    suspend fun deleteStaff(staff: StaffMember)

    @Query("DELETE FROM staff")
    suspend fun deleteAllStaff()
}

@Dao
interface FeedbackDao {
    @Query("SELECT * FROM feedback ORDER BY id DESC")
    fun getAllFeedback(): Flow<List<FeedbackEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFeedback(feedback: FeedbackEntry): Long

    @Query("DELETE FROM feedback")
    suspend fun deleteAllFeedback()
}
