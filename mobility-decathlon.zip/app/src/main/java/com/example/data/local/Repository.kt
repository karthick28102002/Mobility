package com.example.data.local

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class CycleDeliveryRepository(private val db: AppDatabase) {

    private val deliveryDao = db.deliveryDao()
    private val adminDao = db.adminDao()
    private val staffDao = db.staffDao()
    private val feedbackDao = db.feedbackDao()

    // Deliveries Flows & Suspend functions
    val allDeliveries: Flow<List<Delivery>> = deliveryDao.getAllDeliveries()

    fun getDeliveryByIdFlow(id: Int): Flow<Delivery?> = deliveryDao.getDeliveryByIdFlow(id)

    suspend fun getDeliveryById(id: Int): Delivery? = withContext(Dispatchers.IO) {
        deliveryDao.getDeliveryById(id)
    }

    suspend fun getDeliveryByOrderId(orderId: String): Delivery? = withContext(Dispatchers.IO) {
        deliveryDao.getDeliveryByOrderId(orderId)
    }

    fun searchDeliveries(query: String): Flow<List<Delivery>> = deliveryDao.searchDeliveries(query)

    suspend fun insertDelivery(delivery: Delivery): Long = withContext(Dispatchers.IO) {
        deliveryDao.insertDelivery(delivery)
    }

    suspend fun updateDelivery(delivery: Delivery) = withContext(Dispatchers.IO) {
        deliveryDao.updateDelivery(delivery)
    }

    suspend fun deleteDelivery(delivery: Delivery) = withContext(Dispatchers.IO) {
        deliveryDao.deleteDelivery(delivery)
    }

    // Admins Flows & Suspend functions
    val allAdmins: Flow<List<Admin>> = adminDao.getAllAdmins()

    suspend fun getAdminByUsername(username: String): Admin? = withContext(Dispatchers.IO) {
        adminDao.getAdminByUsername(username)
    }

    suspend fun insertAdmin(admin: Admin): Long = withContext(Dispatchers.IO) {
        adminDao.insertAdmin(admin)
    }

    suspend fun deleteAdmin(admin: Admin) = withContext(Dispatchers.IO) {
        adminDao.deleteAdmin(admin)
    }

    // Staff Flows & Suspend functions
    val allStaff: Flow<List<StaffMember>> = staffDao.getAllStaff()

    suspend fun insertStaff(staff: StaffMember): Long = withContext(Dispatchers.IO) {
        staffDao.insertStaff(staff)
    }

    suspend fun updateStaff(staff: StaffMember) = withContext(Dispatchers.IO) {
        staffDao.updateStaff(staff)
    }

    suspend fun deleteStaff(staff: StaffMember) = withContext(Dispatchers.IO) {
        staffDao.deleteStaff(staff)
    }

    // Feedback Flows & Suspend functions
    val allFeedback: Flow<List<FeedbackEntry>> = feedbackDao.getAllFeedback()

    suspend fun insertFeedback(feedback: FeedbackEntry): Long = withContext(Dispatchers.IO) {
        // Automatically save to independent feedback database
        val feedbackId = feedbackDao.insertFeedback(feedback)
        
        // Also sync back to deliveries table if reference deliveryId exists
        feedback.deliveryId?.let { delId ->
            val delivery = deliveryDao.getDeliveryById(delId)
            if (delivery != null) {
                deliveryDao.updateDelivery(
                    delivery.copy(
                        feedbackRating = feedback.rating,
                        feedbackComment = feedback.comment
                    )
                )
            }
        }
        feedbackId
    }

    // Pre-populate data helper
    suspend fun populateInitialDataIfNeeded() = withContext(Dispatchers.IO) {
        val admins = adminDao.getAllAdmins().first()
        if (admins.isEmpty()) {
            // Seed Admins: super admin, and common admin
            adminDao.insertAdmin(
                Admin(
                    username = "Gopal",
                    passwordHash = "Gopal@2026",
                    fullName = "Gopal (Super Admin)",
                    isSuperAdmin = true
                )
            )
            adminDao.insertAdmin(
                Admin(
                    username = "staff1",
                    passwordHash = "staff123",
                    fullName = "Delivery Supervisor Ramesh",
                    isSuperAdmin = false
                )
            )
        }

        // Active database migration / fallback safeguard:
        // Ensure "Gopal" super admin exists and any legacy "admin" super admin is cleaned up
        val oldAdmin = adminDao.getAdminByUsername("admin")
        if (oldAdmin != null) {
            adminDao.deleteAdmin(oldAdmin)
        }
        val hasGopal = adminDao.getAdminByUsername("Gopal")
        if (hasGopal == null) {
            adminDao.insertAdmin(
                Admin(
                    username = "Gopal",
                    passwordHash = "Gopal@2026",
                    fullName = "Gopal (Super Admin)",
                    isSuperAdmin = true
                )
            )
        }
    }

    suspend fun clearDemoDetails() = withContext(Dispatchers.IO) {
        deliveryDao.deleteAllDeliveries()
        staffDao.deleteAllStaff()
        feedbackDao.deleteAllFeedback()
    }

    suspend fun syncPayloadAndMerge(serverPayload: SyncPayload) = withContext(Dispatchers.IO) {
        // 1. Process Deletions Returned by the Server
        serverPayload.deletedAdmins.forEach { username ->
            val local = adminDao.getAdminByUsername(username)
            if (local != null) {
                adminDao.deleteAdmin(local)
            }
        }

        serverPayload.deletedDeliveries.forEach { orderId ->
            val local = deliveryDao.getDeliveryByOrderId(orderId)
            if (local != null) {
                deliveryDao.deleteDelivery(local)
            }
        }

        val currentStaffList = staffDao.getAllStaff().first()
        serverPayload.deletedStaff.forEach { name ->
            val local = currentStaffList.firstOrNull { it.name.trim().lowercase() == name.trim().lowercase() }
            if (local != null) {
                staffDao.deleteStaff(local)
            }
        }

        // 2. Merge Admins by username
        val deletedAdminsSet = serverPayload.deletedAdmins.map { it.trim().lowercase() }.toSet()
        serverPayload.admins.forEach { serverAdmin ->
            if (serverAdmin.username.trim().lowercase() !in deletedAdminsSet) {
                val local = adminDao.getAdminByUsername(serverAdmin.username)
                if (local != null) {
                    adminDao.insertAdmin(serverAdmin.copy(id = local.id))
                } else {
                    adminDao.insertAdmin(serverAdmin.copy(id = 0))
                }
            }
        }

        // 3. Merge Deliveries by orderId
        val deletedDeliveriesSet = serverPayload.deletedDeliveries.toSet()
        serverPayload.deliveries.forEach { serverDel ->
            if (serverDel.orderId !in deletedDeliveriesSet) {
                val local = deliveryDao.getDeliveryByOrderId(serverDel.orderId)
                if (local != null) {
                    deliveryDao.insertDelivery(serverDel.copy(id = local.id))
                } else {
                    deliveryDao.insertDelivery(serverDel.copy(id = 0))
                }
            }
        }

        // 4. Merge Staff members by name
        val deletedStaffSet = serverPayload.deletedStaff.map { it.trim().lowercase() }.toSet()
        val latestStaffList = staffDao.getAllStaff().first()
        serverPayload.staff.forEach { serverStaff ->
            if (serverStaff.name.trim().lowercase() !in deletedStaffSet) {
                val local = latestStaffList.firstOrNull { it.name.trim().lowercase() == serverStaff.name.trim().lowercase() }
                if (local != null) {
                    staffDao.insertStaff(serverStaff.copy(id = local.id))
                } else {
                    staffDao.insertStaff(serverStaff.copy(id = 0))
                }
            }
        }

        // 5. Merge Feedbacks. Compare date and customer details
        val localFeedback = feedbackDao.getAllFeedback().first()
        serverPayload.feedbacks.forEach { serverFb ->
            val exists = localFeedback.any { 
                it.customerName == serverFb.customerName && 
                it.date == serverFb.date && 
                it.rating == serverFb.rating
            }
            if (!exists) {
                feedbackDao.insertFeedback(serverFb.copy(id = 0))
            }
        }
    }
}
