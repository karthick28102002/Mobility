package com.example.data.local

import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

data class SyncPayload(
    val deliveries: List<Delivery>,
    val admins: List<Admin>,
    val staff: List<StaffMember>,
    val feedbacks: List<FeedbackEntry>,
    val deletedAdmins: List<String> = emptyList(),
    val deletedDeliveries: List<String> = emptyList(),
    val deletedStaff: List<String> = emptyList()
)

interface SyncApi {
    @POST("sync")
    suspend fun syncData(@Body payload: SyncPayload): SyncPayload
}

object RetrofitClient {
    fun getSyncApi(baseUrl: String, specifiedApiKey: String? = null): SyncApi {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        
        val apiKey = if (!specifiedApiKey.isNullOrBlank() && specifiedApiKey != "SYNC_API_KEY_PLACEHOLDER") {
            specifiedApiKey
        } else {
            val buildConfigKey = BuildConfig.SYNC_API_KEY
            if (!buildConfigKey.isNullOrBlank() && buildConfigKey != "SYNC_API_KEY_PLACEHOLDER") {
                buildConfigKey
            } else {
                "9dc9e9e41beb28638baacb7a743e1740e815a6d43266ee204ace638676e83164c662ed8b898669653849f9a0b82e1fd1dfae1c71fe9bb01d43e98a8d440b89fb"
            }
        }
        
        val client = OkHttpClient.Builder()
            .addInterceptor { chain ->
                val original = chain.request()
                val requestBuilder = original.newBuilder()
                // Inject Sync API Key securely if defined
                if (!apiKey.isNullOrBlank() && apiKey != "SYNC_API_KEY_PLACEHOLDER") {
                    requestBuilder.header("Authorization", "Bearer $apiKey")
                    requestBuilder.header("X-API-Key", apiKey)
                    requestBuilder.header("x-api-key", apiKey)
                }
                chain.proceed(requestBuilder.build())
            }
            .addInterceptor(logging)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()

        val normalizedUrl = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"

        val moshi = Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(normalizedUrl)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()

        return retrofit.create(SyncApi::class.java)
    }
}
