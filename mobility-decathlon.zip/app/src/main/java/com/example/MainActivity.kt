package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainAppView
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.DeliveryViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val viewModel: DeliveryViewModel = viewModel()
      val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
      androidx.compose.runtime.LaunchedEffect(systemDark) {
        // Only override on initial startup to match system defaults
        viewModel.isDarkTheme = systemDark
      }
      MyApplicationTheme(darkTheme = false) {
        Surface(modifier = Modifier.fillMaxSize()) {
          BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val widthSizeClass = if (maxWidth >= 720.dp) "Expanded" else "Compact"
            MainAppView(viewModel = viewModel, widthSizeClass = widthSizeClass)
          }
        }
      }
    }
  }
}
