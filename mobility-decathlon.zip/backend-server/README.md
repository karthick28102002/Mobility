# Decathlon Cloud Delivery - Central Sync Backend Servers

This workspace includes two alternative, ready-to-use implementations for the central sync backend database server. By connecting multiple Decathlon Admin mobile app clients to either backend option, updates from one administrator (e.g. creating/deleting deliveries, assigning riders, validating OTPs) are immediately and atomically merged and synchronized across all other devices in real-time!

---

## 🏗️ Supported Engines & Implementations

### Option A: Node.js (with Express)
* **Stack**: Node.js, Express, Body-Parser, CORS.
* **Database**: Local JSON-file storage (`db.json`) with automated atomic merging.
* **Features**: Live Material Design 3 HTML dashboard at `http://localhost:3000/`.

### Option B: PHP (High Compatibility)
* **Stack**: Standard PHP 7.4 or newer (No extra packages or frameworks required).
* **Database**: Local JSON-file storage (`db.json`) shared/fully interchangeable with the Node version.
* **Features**: Zero-dependency single-file deployment, live Material 3 HTML dashboard built in, perfect for shared hosting (GoDaddy, Hostinger, Bluehost, Namecheap, etc.) or local Apache/XAMPP.

---

## ⚡ Setup & Deployment Guides

### 1. Running the Node.js Server
* Prerequisite: [Node.js](https://nodejs.org/) (v16.0.0 or higher recommended).
1. Navigate to the server directory:
   ```bash
   cd backend-server
   ```
2. Install standard dependencies:
   ```bash
   npm install
   ```
3. Boot up the server:
   ```bash
   npm run start
   ```
   * Access the dashboard at: `http://localhost:3000/`
   * Sync API endpoint URL to enter in the app: `http://<YOUR_LOCAL_IP>:3000`

---

### 2. Running or Deploying the PHP Script
* Prerequisite: Any standard PHP-enabled web hosting server or local server suite like XAMPP or MAMP.
1. Upload `/backend-server/index.php` directly to your server's web directory (e.g. `public_html/` or `htdocs/`).
2. Verify that the folder hosting `index.php` is **writeable** by the web server (so it can automatically generate and write synchronized records to `db.json`).
3. View the live Web Dashboard:
   * Navigate to: `http://<YOUR_DOMAIN_OR_HOST>/index.php` in your browser.
4. Input in your Admin Mobile App settings:
   * Sync API endpoint URL: `http://<YOUR_DOMAIN_OR_HOST>/index.php`

---

## 🛡️ Optional: Adding API Key Protection
Both backends support optional bearer authentication headers to lock down and protect your endpoints.
1. Define a secure key in your server environment:
   * **Node.js**: Set environment variable `SYNC_API_KEY` (e.g., in `.env`).
   * **PHP**: Change `DEFAULT_SYNC_API_KEY` in `index.php` or set server environment variable `SYNC_API_KEY`.
2. Configure the key securely in the Android app via the AI Studio Secrets Panel using the `SYNC_API_KEY` tag.

---

## 📲 Connecting Your Mobile Clients

1. Ensure the host computer/server is accessible via network protocols from the Android device/Emulator.
2. Open the Decathlon Admin mobile app on the device.
3. Log in with a **Super Admin** account (e.g., `Gopal`).
4. Go to the **Cloud Sync** tab.
5. Set **Enable Cloud Sync** to **ON**.
6. Enter your chosen endpoint base URL (e.g., `http://10.0.2.2:3000` for default emulator bridge to your computer's Node.js port, or `https://mydecathlonsync.com` for a hosted PHP script).
7. Save Configuration to start immediate bidirectional background sync!

