-- ==========================================
-- DECATHLON CLOUD DELIVERY DATABASE SCHEMA
-- Compatible with MySQL and PostgreSQL
-- ==========================================

-- Select target database syntax by uncommenting or copying appropriate blocks below.

----------------------------------------------------
-- SECTION 1: MySQL Schema
----------------------------------------------------

/*
CREATE DATABASE IF NOT EXISTS decathlon_delivery;
USE decathlon_delivery;

-- 1. Users/Admins Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    passwordHash VARCHAR(255) NOT NULL,
    fullName VARCHAR(255) NOT NULL,
    isSuperAdmin BOOLEAN DEFAULT FALSE,
    role VARCHAR(50) DEFAULT 'Admin', -- Admin, Super Admin, Auditor, Dispatcher
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Staff Members (Drivers/Riders) Table
CREATE TABLE IF NOT EXISTS staff (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'Active', -- Active, Hand-off, On Delivery, Resting
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Deliveries Table
CREATE TABLE IF NOT EXISTS deliveries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    orderId VARCHAR(100) UNIQUE NOT NULL,
    customerName VARCHAR(255) NOT NULL,
    phoneNumber VARCHAR(50) NOT NULL,
    cycleModel VARCHAR(255) NOT NULL,
    address TEXT NOT NULL,
    deliveryDate VARCHAR(100) NOT NULL,
    deliveryTime VARCHAR(100) NOT NULL,
    photoUri VARCHAR(1000) DEFAULT NULL,
    staffName VARCHAR(255) DEFAULT '',
    deliveryStatus VARCHAR(100) NOT NULL DEFAULT 'Booking', -- Booking -> Booked -> Assigned -> Out for Delivery -> Delivered
    deliveryMethod VARCHAR(100) NOT NULL DEFAULT 'Store Delivery', -- ACE Order, Customer Pickup, Store Delivery
    otp VARCHAR(20) DEFAULT '',
    otpVerified BOOLEAN DEFAULT FALSE,
    feedbackRating FLOAT DEFAULT NULL,
    feedbackComment TEXT DEFAULT NULL,
    deliveryCompletedTime VARCHAR(100) DEFAULT NULL,
    timestamp BIGINT DEFAULT 0, -- Atomic clock sync value
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Feedback Table
CREATE TABLE IF NOT EXISTS feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    deliveryId INT DEFAULT NULL,
    customerName VARCHAR(255) NOT NULL,
    phoneNumber VARCHAR(50) NOT NULL,
    rating FLOAT NOT NULL,
    comment TEXT NOT NULL,
    date VARCHAR(100) NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Photos Table (Proof of Delivery / Cycle Assembly Photos)
CREATE TABLE IF NOT EXISTS photos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    deliveryId INT DEFAULT NULL,
    orderId VARCHAR(100) NOT NULL,
    photoUrl VARCHAR(1000) NOT NULL,
    uploadedBy VARCHAR(255) NOT NULL, -- Username of admin/rider uploading it
    uploadedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Audit Logs Table (Operational Trail)
CREATE TABLE IF NOT EXISTS audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    action VARCHAR(255) NOT NULL, -- e.g., CREATE_DELIVERY, UPDATE_STATUS, LOGIN
    username VARCHAR(100) NOT NULL,
    details TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed default initial superadmin user (Password: Gopal@2026)
INSERT INTO users (username, passwordHash, fullName, isSuperAdmin, role) 
VALUES ('Gopal', '$2b$10$DecathlonSecuritySaltForHashHashingWithGopalPasswordGopal2026', 'Gopal (Super Admin)', TRUE, 'Super Admin')
ON DUPLICATE KEY UPDATE username=username;

-- Seed default initial staff
INSERT INTO staff (name, phone, status) VALUES 
('Arun Kumar', '9876543210', 'Active'),
('Priya Raj', '8765432109', 'Active');
*/


----------------------------------------------------
-- SECTION 2: PostgreSQL Schema
----------------------------------------------------

/*
-- 1. Users/Admins Table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    passwordHash VARCHAR(255) NOT NULL,
    fullName VARCHAR(255) NOT NULL,
    isSuperAdmin BOOLEAN DEFAULT FALSE,
    role VARCHAR(50) DEFAULT 'Admin',
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Staff Members Table
CREATE TABLE IF NOT EXISTS staff (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'Active',
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Deliveries Table
CREATE TABLE IF NOT EXISTS deliveries (
    id SERIAL PRIMARY KEY,
    orderId VARCHAR(100) UNIQUE NOT NULL,
    customerName VARCHAR(255) NOT NULL,
    phoneNumber VARCHAR(50) NOT NULL,
    cycleModel VARCHAR(255) NOT NULL,
    address TEXT NOT NULL,
    deliveryDate VARCHAR(100) NOT NULL,
    deliveryTime VARCHAR(100) NOT NULL,
    photoUri VARCHAR(1000) DEFAULT NULL,
    staffName VARCHAR(255) DEFAULT '',
    deliveryStatus VARCHAR(100) NOT NULL DEFAULT 'Booking',
    deliveryMethod VARCHAR(100) NOT NULL DEFAULT 'Store Delivery',
    otp VARCHAR(20) DEFAULT '',
    otpVerified BOOLEAN DEFAULT FALSE,
    feedbackRating REAL DEFAULT NULL,
    feedbackComment TEXT DEFAULT NULL,
    deliveryCompletedTime VARCHAR(100) DEFAULT NULL,
    timestamp BIGINT DEFAULT 0,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. Feedback Table
CREATE TABLE IF NOT EXISTS feedback (
    id SERIAL PRIMARY KEY,
    deliveryId INT DEFAULT NULL,
    customerName VARCHAR(255) NOT NULL,
    phoneNumber VARCHAR(50) NOT NULL,
    rating REAL NOT NULL,
    comment TEXT NOT NULL,
    date VARCHAR(100) NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. Photos Table
CREATE TABLE IF NOT EXISTS photos (
    id SERIAL PRIMARY KEY,
    deliveryId INT DEFAULT NULL,
    orderId VARCHAR(100) NOT NULL,
    photoUrl VARCHAR(1000) NOT NULL,
    uploadedBy VARCHAR(255) NOT NULL,
    uploadedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 6. Audit Logs Table
CREATE TABLE IF NOT EXISTS audit_logs (
    id SERIAL PRIMARY KEY,
    action VARCHAR(255) NOT NULL,
    username VARCHAR(100) NOT NULL,
    details TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed default initial superadmin user (Password: Gopal@2026)
INSERT INTO users (username, passwordHash, fullName, isSuperAdmin, role) 
VALUES ('Gopal', '$2b$10$DecathlonSecuritySaltForHashHashingWithGopalPasswordGopal2026', 'Gopal (Super Admin)', TRUE, 'Super Admin')
ON CONFLICT (username) DO NOTHING;

-- Seed default initial staff
INSERT INTO staff (name, phone, status) VALUES 
('Arun Kumar', '9876543210', 'Active'),
('Priya Raj', '8765432109', 'Active');
*/
