const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Load local .env variables if present
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, 'utf8');
  envContent.split('\n').forEach(line => {
    const trimmed = line.trim();
    if (trimmed && !trimmed.startsWith('#') && trimmed.includes('=')) {
      const parts = trimmed.split('=');
      const key = parts[0].trim();
      const val = parts.slice(1).join('=').trim().replace(/^['"]|['"]$/g, ''); // Trim quotes if any
      if (key && val && !process.env[key]) {
        process.env[key] = val;
      }
    }
  });
}

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'db.json');
const UPLOADS_DIR = path.join(__dirname, 'uploads');
const JWT_SECRET = process.env.JWT_SECRET || 'decathlon_mobility_jwt_secure_secret_2026';

// Create directories if missing
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Middleware setup
app.use(cors());
app.use(bodyParser.json({ limit: '100mb' }));
app.use(bodyParser.urlencoded({ limit: '100mb', extended: true }));
app.use('/uploads', express.static(UPLOADS_DIR));

// ==========================================
// SEED & SECURITY UTILITIES
// ==========================================

// Password Hasher (SHA-256 with static enterprise salt)
function hashPassword(password) {
  const salt = 'decathlon_secure_hash_salt_2026';
  return crypto.createHmac('sha256', salt).update(password).digest('hex');
}

// Zero-Dependency Light JWT Sign/Verify Implementations
function base64UrlEncode(str) {
  return Buffer.from(str).toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

function base64UrlDecode(str) {
  str = str.replace(/-/g, '+').replace(/_/g, '/');
  while (str.length % 4) {
    str += '=';
  }
  return Buffer.from(str, 'base64').toString('utf8');
}

function generateJWT(payload) {
  const header = { alg: 'HS256', typ: 'JWT' };
  const headerStr = base64UrlEncode(JSON.stringify(header));
  const payloadStr = base64UrlEncode(JSON.stringify({ ...payload, exp: Math.floor(Date.now() / 1000) + (3600 * 24) })); // 24hr expiration
  const signatureInput = `${headerStr}.${payloadStr}`;
  const hmac = crypto.createHmac('sha256', JWT_SECRET).update(signatureInput).digest();
  const signature = base64UrlEncode(hmac);
  return `${signatureInput}.${signature}`;
}

function verifyJWT(token) {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const [headerStr, payloadStr, signature] = parts;
    const signatureInput = `${headerStr}.${payloadStr}`;
    const hmac = crypto.createHmac('sha256', JWT_SECRET).update(signatureInput).digest();
    const expectedSignature = base64UrlEncode(hmac);
    if (signature !== expectedSignature) return null;
    
    const payload = JSON.parse(base64UrlDecode(payloadStr));
    if (payload.exp && Date.now() / 1000 > payload.exp) {
      return null; // Expired
    }
    return payload;
  } catch (e) {
    return null;
  }
}

// Initial seeding state of the offline database
const initialDb = {
  deliveries: [],
  admins: [
    {
      id: 1,
      username: "Gopal",
      passwordHash: hashPassword("Gopal@2026"),
      fullName: "Gopal (Super Admin)",
      isSuperAdmin: true,
      role: "Super Admin"
    },
    {
      id: 2,
      username: "staff1",
      passwordHash: hashPassword("staff123"),
      fullName: "Delivery Supervisor Ramesh",
      isSuperAdmin: false,
      role: "Admin"
    }
  ],
  staff: [
    { id: 1, name: "Arun Kumar", phone: "9876543210", status: "Active" },
    { id: 2, name: "Priya Raj", phone: "8765432109", status: "Active" }
  ],
  feedbacks: [],
  photos: [],
  audit_logs: [
    {
      id: 1,
      action: "SYSTEM_START",
      username: "System Server",
      details: "Decathlon Cloud Delivery Sync Engine successfully launched",
      timestamp: new Date().toISOString()
    }
  ]
};

// Database state management
function loadDatabase() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, 'utf8');
      const db = JSON.parse(data);
      // Ensure all schema objects exist
      if (!db.deliveries) db.deliveries = [];
      if (!db.admins) db.admins = [];
      if (!db.staff) db.staff = [];
      if (!db.feedbacks) db.feedbacks = [];
      if (!db.photos) db.photos = [];
      if (!db.audit_logs) db.audit_logs = [];
      if (!db.deletedDeliveries) db.deletedDeliveries = [];
      if (!db.deletedAdmins) db.deletedAdmins = [];
      if (!db.deletedStaff) db.deletedStaff = [];
      return db;
    }
  } catch (error) {
    console.error("Error reading database, resetting:", error);
  }
  saveDatabase(initialDb);
  return initialDb;
}

function saveDatabase(data) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf8');
  } catch (error) {
    console.error("Error writing database file:", error);
  }
}

function logAuditAction(action, username, details) {
  try {
    const db = loadDatabase();
    const log = {
      id: db.audit_logs.length + 1,
      action,
      username,
      details,
      timestamp: new Date().toISOString()
    };
    db.audit_logs.push(log);
    saveDatabase(db);
  } catch (e) {
    console.error("Audit log failed: ", e);
  }
}

// ==========================================
// MIDDLEWARES FOR JWT AND ROLES
// ==========================================
function authenticateToken(req, res, next) {
  // We support BOTH JWT bearer tokens and traditional client API keys
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  const apiKey = req.headers['x-api-key'] || req.headers['X-API-Key'];

  const expectedApiKey = process.env.SYNC_API_KEY || '';

  // 1. Check for API key fallback (machine/sync connection)
  if (apiKey && expectedApiKey && apiKey.trim() === expectedApiKey.trim()) {
    req.user = { username: "Sync-Worker", role: "Super Admin", isSuperAdmin: true };
    return next();
  }

  // 2. Check for traditional JWT Authentication
  if (!token) {
    // If no client API key or token is configured, allow sync as sandbox fallback
    if (!expectedApiKey && req.path.includes('/sync')) {
      req.user = { username: "Sandbox-User", role: "Super Admin", isSuperAdmin: true };
      return next();
    }
    return res.status(401).json({ error: "Access Denied: Missing Authentication Token / Bearer Header" });
  }

  const user = verifyJWT(token);
  if (!user) {
    return res.status(403).json({ error: "Forbidden: Signature Mismatch or Expired JWT Token" });
  }

  req.user = user;
  next();
}

function requireSuperAdmin(req, res, next) {
  if (req.user && (req.user.isSuperAdmin || req.user.role === 'Super Admin')) {
    next();
  } else {
    res.status(403).json({ error: "Access Denied: Super Admin privileges are required to perform this action" });
  }
}

// ==========================================
// REST API ENDPOINTS
// ==========================================

// Authenticate and Login -> Returns JWT and Account Details
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: "Please enter both username and password" });
  }

  const db = loadDatabase();
  const user = db.admins.find(a => a.username.trim().toLowerCase() === username.trim().toLowerCase());
  
  if (!user) {
    logAuditAction("LOGIN_FAILURE", username, "Attempted login with non-existent username");
    return res.status(401).json({ error: "Incorrect username or password entered" });
  }

  const hashedInput = hashPassword(password);
  // Match standard hashed password or default unhashed (fallback for ease of setup)
  if (user.passwordHash !== hashedInput && user.passwordHash !== password) {
    logAuditAction("LOGIN_FAILURE", username, "Incorrect password attempt");
    return res.status(401).json({ error: "Incorrect username or password entered" });
  }

  // Generate complete JWT Payload
  const jwtPayload = {
    id: user.id,
    username: user.username,
    fullName: user.fullName,
    role: user.isSuperAdmin ? "Super Admin" : "Admin",
    isSuperAdmin: user.isSuperAdmin
  };
  const token = generateJWT(jwtPayload);

  logAuditAction("LOGIN_SUCCESS", user.username, `Successful session started for ${user.fullName}`);
  res.json({
    message: "Login successful",
    token,
    user: jwtPayload
  });
});

// Dynamic Two-Way Merge Synchronization Endpoint
const syncHandler = (req, res) => {
  const clientPayload = req.body;
  if (!clientPayload) {
    return res.status(400).json({ error: "Missing sync request payload" });
  }

  const db = loadDatabase();

  // Initialize tombstone lists on server if not present
  if (!db.deletedAdmins) db.deletedAdmins = [];
  if (!db.deletedDeliveries) db.deletedDeliveries = [];
  if (!db.deletedStaff) db.deletedStaff = [];

  // 0. Process Incoming Deletions from Client
  if (Array.isArray(clientPayload.deletedAdmins)) {
    clientPayload.deletedAdmins.forEach(username => {
      const uLower = username.trim().toLowerCase();
      // Remove from active list
      const idx = db.admins.findIndex(a => a.username.trim().toLowerCase() === uLower);
      if (idx !== -1) {
        logAuditAction("DELETE_ADMIN", req.user?.username || "Sync-Client", `Admin account ${db.admins[idx].username} deleted during sync`);
        db.admins.splice(idx, 1);
      }
      // Record in tombstone
      if (!db.deletedAdmins.some(u => u.trim().toLowerCase() === uLower)) {
        db.deletedAdmins.push(username);
      }
    });
  }

  if (Array.isArray(clientPayload.deletedDeliveries)) {
    clientPayload.deletedDeliveries.forEach(orderId => {
      const idx = db.deliveries.findIndex(d => d.orderId === orderId);
      if (idx !== -1) {
        logAuditAction("DELETE_DELIVERY", req.user?.username || "Sync-Client", `Order ${orderId} deleted during sync`);
        db.deliveries.splice(idx, 1);
      }
      if (!db.deletedDeliveries.includes(orderId)) {
        db.deletedDeliveries.push(orderId);
      }
    });
  }

  if (Array.isArray(clientPayload.deletedStaff)) {
    clientPayload.deletedStaff.forEach(name => {
      const sLower = name.trim().toLowerCase();
      const idx = db.staff.findIndex(s => s.name.trim().toLowerCase() === sLower);
      if (idx !== -1) {
        logAuditAction("DELETE_STAFF", req.user?.username || "Sync-Client", `Staff ${db.staff[idx].name} profiles removed during sync`);
        db.staff.splice(idx, 1);
      }
      if (!db.deletedStaff.some(n => n.trim().toLowerCase() === sLower)) {
        db.deletedStaff.push(name);
      }
    });
  }

  // 1. Merge Admins (by unique username)
  if (Array.isArray(clientPayload.admins)) {
    clientPayload.admins.forEach(clientAdmin => {
      const uLower = clientAdmin.username.trim().toLowerCase();
      
      // If this admin is deleted, skip merging it back
      if (db.deletedAdmins.some(u => u.trim().toLowerCase() === uLower)) {
        return;
      }
      
      const existingIdx = db.admins.findIndex(a => a.username.trim().toLowerCase() === uLower);
      if (existingIdx !== -1) {
        db.admins[existingIdx] = { ...db.admins[existingIdx], ...clientAdmin };
      } else {
        const maxId = db.admins.reduce((max, a) => Math.max(max, a.id || 0), 0);
        db.admins.push({ ...clientAdmin, id: maxId + 1 });
      }
    });
  }

  // 2. Merge Staff (by unique name)
  if (Array.isArray(clientPayload.staff)) {
    clientPayload.staff.forEach(clientStaff => {
      const sLower = clientStaff.name.trim().toLowerCase();
      
      // If this staff member is deleted, skip merging it back
      if (db.deletedStaff.some(n => n.trim().toLowerCase() === sLower)) {
        return;
      }
      
      const existingIdx = db.staff.findIndex(s => s.name.trim().toLowerCase() === sLower);
      if (existingIdx !== -1) {
        db.staff[existingIdx] = { ...db.staff[existingIdx], ...clientStaff };
      } else {
        const maxId = db.staff.reduce((max, s) => Math.max(max, s.id || 0), 0);
        db.staff.push({ ...clientStaff, id: maxId + 1 });
      }
    });
  }

  // 3. Merge Deliveries (by unique orderId using atomic conflict matching)
  let statusUpdatedCount = 0;
  if (Array.isArray(clientPayload.deliveries)) {
    clientPayload.deliveries.forEach(clientDel => {
      // If this delivery is deleted, skip merging it back
      if (db.deletedDeliveries.includes(clientDel.orderId)) {
        return;
      }
      
      const existingIdx = db.deliveries.findIndex(d => d.orderId === clientDel.orderId);
      if (existingIdx !== -1) {
        const existing = db.deliveries[existingIdx];
        if ((clientDel.timestamp || 0) >= (existing.timestamp || 0)) {
          if (existing.deliveryStatus !== clientDel.deliveryStatus) {
            statusUpdatedCount++;
            logAuditAction(
              "STATUS_CHANGE", 
              req.user?.username || "Sync-Client", 
              `Order ${clientDel.orderId} transition: ${existing.deliveryStatus} -> ${clientDel.deliveryStatus}`
            );
          }
          db.deliveries[existingIdx] = { ...existing, ...clientDel };
        }
      } else {
        const maxId = db.deliveries.reduce((max, d) => Math.max(max, d.id || 0), 0);
        db.deliveries.push({ ...clientDel, id: maxId + 1 });
        logAuditAction("SYNC_DELIVERY_INSERT", req.user?.username || "Sync-Client", `Synced new Order #${clientDel.orderId}`);
      }
    });
  }

  // 4. Merge Feedbacks
  if (Array.isArray(clientPayload.feedbacks)) {
    clientPayload.feedbacks.forEach(clientFb => {
      const isDuplicate = db.feedbacks.some(f => 
        f.customerName === clientFb.customerName && 
        f.date === clientFb.date && 
        f.rating === clientFb.rating
      );
      if (!isDuplicate) {
        const maxId = db.feedbacks.reduce((max, f) => Math.max(max, f.id || 0), 0);
        db.feedbacks.push({ ...clientFb, id: maxId + 1 });
        logAuditAction("FEEDBACK_RECEIVED", "Customer", `Received ${clientFb.rating}★ feedback for customer ${clientFb.customerName}`);
      }
    });
  }

  saveDatabase(db);

  // Return full master state back to devices
  const responsePayload = {
    deliveries: db.deliveries,
    admins: db.admins,
    staff: db.staff,
    feedbacks: db.feedbacks,
    deletedDeliveries: db.deletedDeliveries,
    deletedAdmins: db.deletedAdmins,
    deletedStaff: db.deletedStaff
  };

  res.json(responsePayload);
};

// Mount Sync routes
app.post('/sync', authenticateToken, syncHandler);
app.post('/api/sync', authenticateToken, syncHandler);

// Add API log tracking audit logs endpoint
app.get('/api/audit-logs', authenticateToken, (req, res) => {
  const db = loadDatabase();
  res.json(db.audit_logs || []);
});

// Photo Upload Endpoint (JWT protected)
app.post('/api/photos/upload', authenticateToken, (req, res) => {
  const { orderId, photoBase64 } = req.body;
  if (!orderId || !photoBase64) {
    return res.status(400).json({ error: "Missing orderId or photoBase64 payload" });
  }

  const db = loadDatabase();
  let cleanBase64 = photoBase64;
  if (photoBase64.startsWith("data:image")) {
    cleanBase64 = photoBase64.split(",")[1];
  }

  const fileName = `POD_${orderId}_${Date.now()}.jpg`;
  const relativePath = `/uploads/${fileName}`;
  const localFilePath = path.join(UPLOADS_DIR, fileName);

  try {
    fs.writeFileSync(localFilePath, Buffer.from(cleanBase64, 'base64'));
    
    // Supplement delivery object with photo
    const existingIdx = db.deliveries.findIndex(d => d.orderId === orderId);
    if (existingIdx !== -1) {
      db.deliveries[existingIdx].photoUri = relativePath;
      db.deliveries[existingIdx].timestamp = Date.now();
    }

    const photoObj = {
      id: db.photos.length + 1,
      orderId,
      photoUrl: relativePath,
      uploadedBy: req.user.username,
      uploadedAt: new Date().toISOString()
    };
    db.photos.push(photoObj);
    saveDatabase(db);

    logAuditAction("PHOTO_UPLOAD", req.user.username, `Uploaded proof of delivery for Order #${orderId}`);
    res.json({ message: "Photo uploaded and matched successfully", photo: photoObj });
  } catch (err) {
    res.status(500).json({ error: "Failed to write photo payload to server directory" });
  }
});

// Pull analytics daily reports
app.get('/api/reports/daily', authenticateToken, (req, res) => {
  const db = loadDatabase();
  const reportsObj = {};
  
  db.deliveries.forEach(d => {
    const date = d.deliveryDate || "Unknown Date";
    if (!reportsObj[date]) {
      reportsObj[date] = { date, total: 0, pending: 0, delivered: 0, pickedUp: 0, ratingSum: 0, ratingCount: 0 };
    }
    reportsObj[date].total++;
    if (d.deliveryStatus === 'Delivered') {
      reportsObj[date].delivered++;
    } else if (d.deliveryStatus === 'Booking' || d.deliveryStatus === 'Booked') {
      reportsObj[date].pending++;
    } else {
      reportsObj[date].pickedUp++;
    }
    if (d.feedbackRating) {
      reportsObj[date].ratingSum += d.feedbackRating;
      reportsObj[date].ratingCount++;
    }
  });

  const reportsArray = Object.values(reportsObj).map(r => ({
    ...r,
    avgRating: r.ratingCount > 0 ? (r.ratingSum / r.ratingCount).toFixed(1) : "N/A"
  }));

  res.json(reportsArray);
});

// Admin Reset Tool (Requires Super Admin Role)
app.post('/api/reset', [authenticateToken, requireSuperAdmin], (req, res) => {
  saveDatabase(initialDb);
  logAuditAction("DATABASE_RESET", req.user.username, "Initiated database schema default factory reset");
  res.json({ message: "Database reset to initial default state successfully!" });
});

// ==========================================
// ENTERPRISE DATABASE ADAPTOR WORKSHOP (DOCUMENTATION)
// ==========================================
/**
 * TO CONVERT THIS JSON-FILE BASE INTO A PRODUCTION SQL POOL (MySQL / PostgreSQL):
 * 
 * 1. Install knex or pg/mysql2 driver:
 *    npm install knex pg mysql2
 * 
 * 2. Setup connection pooling in a database file (e.g., db_pool.js):
 *    const knex = require('knex')({
 *      client: 'pg', // or 'mysql2'
 *      connection: {
 *        host : '127.0.0.1',
 *        port : 5432,
 *        user : 'decathlon_admin',
 *        password : 'SecurePassword2026',
 *        database : 'decathlon_delivery'
 *      },
 *      pool: { min: 2, max: 10 }
 *    });
 *    module.exports = knex;
 * 
 * 3. Replace loadDatabase/mergeSyncData with raw transactions:
 *    async function syncHandlerSQL(req, res) {
 *      const trx = await knex.transaction();
 *      try {
 *        // Select & update matching entities atomically (e.g. SELECT FOR UPDATE):
 *        for (let d of req.body.deliveries) {
 *           const existing = await trx('deliveries').where({ orderId: d.orderId }).first();
 *           if (!existing) {
 *              await trx('deliveries').insert(d);
 *           } else if (d.timestamp >= existing.timestamp) {
 *              await trx('deliveries').where({ orderId: d.orderId }).update(d);
 *           }
 *        }
 *        await trx.commit();
 *        // Query updated list and return...
 *      } catch (err) {
 *        await trx.rollback();
 *      }
 *    }
 */

// ==========================================
// DYNAMIC DELETE ENDPOINTS FOR THE WEB PORTAL
// ==========================================
app.post('/api/delete/delivery', (req, res) => {
  const { orderId } = req.body;
  if (!orderId) {
    return res.status(400).json({ error: "Missing orderId" });
  }
  const db = loadDatabase();
  const dIndex = db.deliveries.findIndex(d => d.orderId === orderId);
  if (dIndex !== -1) {
    db.deliveries.splice(dIndex, 1);
    if (!db.deletedDeliveries) db.deletedDeliveries = [];
    if (!db.deletedDeliveries.includes(orderId)) {
      db.deletedDeliveries.push(orderId);
    }
    saveDatabase(db);
    logAuditAction("DELETE_DELIVERY", "Web-Portal", `Order ${orderId} deleted from web portal`);
    return res.json({ success: true, message: `Delivery sequence ${orderId} deleted successfully.` });
  }
  return res.status(404).json({ error: "Delivery not found" });
});

app.post('/api/delete/staff', (req, res) => {
  const { name } = req.body;
  if (!name) {
    return res.status(400).json({ error: "Missing staff name" });
  }
  const db = loadDatabase();
  const sIndex = db.staff.findIndex(s => s.name.trim().toLowerCase() === name.trim().toLowerCase());
  if (sIndex !== -1) {
    const originalName = db.staff[sIndex].name;
    db.staff.splice(sIndex, 1);
    if (!db.deletedStaff) db.deletedStaff = [];
    const sLower = originalName.trim().toLowerCase();
    if (!db.deletedStaff.some(n => n.trim().toLowerCase() === sLower)) {
      db.deletedStaff.push(originalName);
    }
    saveDatabase(db);
    logAuditAction("DELETE_STAFF", "Web-Portal", `Staff ${originalName} deleted from web portal`);
    return res.json({ success: true, message: `Staff ${originalName} deleted successfully.` });
  }
  return res.status(404).json({ error: "Staff member not found" });
});

app.post('/api/delete/admin', (req, res) => {
  const { username } = req.body;
  if (!username) {
    return res.status(400).json({ error: "Missing username" });
  }
  const db = loadDatabase();
  const aIndex = db.admins.findIndex(a => a.username.trim().toLowerCase() === username.trim().toLowerCase());
  if (aIndex !== -1) {
    const adminUser = db.admins[aIndex].username;
    // Do not allow deleting Gopal or staff1 (default accounts)
    if (adminUser.toLowerCase() === 'gopal' || adminUser.toLowerCase() === 'staff1') {
      return res.status(400).json({ error: "Cannot delete default administrative account" });
    }
    db.admins.splice(aIndex, 1);
    if (!db.deletedAdmins) db.deletedAdmins = [];
    const uLower = adminUser.trim().toLowerCase();
    if (!db.deletedAdmins.some(u => u.trim().toLowerCase() === uLower)) {
      db.deletedAdmins.push(adminUser);
    }
    saveDatabase(db);
    logAuditAction("DELETE_ADMIN", "Web-Portal", `Admin account ${adminUser} deleted from web portal`);
    return res.json({ success: true, message: `Admin ${adminUser} account deleted successfully.` });
  }
  return res.status(404).json({ error: "Admin not found" });
});

// ==========================================
// CENTRAL WEB DASHBOARD PORTAL (MATERIAL 3)
// ==========================================
app.get('/', (req, res) => {
  const db = loadDatabase();
  
  // Dynamic daily stats aggregation
  const totalCount = db.deliveries.length;
  const pendingCount = db.deliveries.filter(d => d.deliveryStatus !== 'Delivered').length;
  const completedCount = db.deliveries.filter(d => d.deliveryStatus === 'Delivered').length;
  const feedbackAvg = db.feedbacks.length > 0 
    ? (db.feedbacks.reduce((sum, f) => sum + f.rating, 0) / db.feedbacks.length).toFixed(1) 
    : 'N/A';

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Decathlon Cloud Delivery - Sync Panel Portal</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Material Design 3 Styling Framework via Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @media print {
      body { background: white !important; font-size: 12px; }
      .no-print { display: none !important; }
      .card-stat { border: 1px solid #ccc !important; box-shadow: none !important; }
    }
  </style>
</head>
<body class="bg-slate-50 text-slate-900 font-sans min-h-screen">

  <header class="bg-blue-700 text-white shadow-md py-4 px-6 no-print">
    <div class="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
      <div class="flex items-center gap-3">
        <span class="bg-white text-blue-700 font-black px-4 py-1.5 rounded text-lg tracking-widest">DECATHLON</span>
        <div>
          <h1 class="text-xl font-bold">Cloud Delivery Sync Center</h1>
          <span class="text-xs text-blue-200">Management & Audit Control Tower Portal</span>
        </div>
      </div>
      <div class="flex items-center gap-3">
        <span class="text-sm bg-blue-800 text-blue-100 px-3 py-1.5 rounded-full font-medium">✨ Connected to JSON File System</span>
        <button onclick="window.print()" class="bg-blue-600 hover:bg-blue-500 font-bold px-4 py-1.5 rounded text-sm transition shadow-sm">
          🖨️ Export to PDF / Print
        </button>
      </div>
    </div>
  </header>

  <main class="max-w-7xl mx-auto py-8 px-4">
    
    <!-- SYSTEM SUMMARY CARDS -->
    <section class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 card-stat">
        <p class="text-xs font-bold text-slate-500 uppercase tracking-semibold mb-1">Total Deliveries</p>
        <div class="flex items-baseline gap-2">
          <span class="text-4xl font-extrabold text-slate-900">${totalCount}</span>
          <span class="text-xs text-green-600 font-medium">📦 Active</span>
        </div>
      </div>
      <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 card-stat">
        <p class="text-xs font-bold text-slate-500 uppercase tracking-semibold mb-1">Pending / Hand-off</p>
        <div class="flex items-baseline gap-2">
          <span class="text-4xl font-extrabold text-orange-600">${pendingCount}</span>
          <span class="text-xs text-orange-500">Scheduled</span>
        </div>
      </div>
      <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 card-stat">
        <p class="text-xs font-bold text-slate-500 uppercase tracking-semibold mb-1">Delivered Successfully</p>
        <div class="flex items-baseline gap-2">
          <span class="text-4xl font-extrabold text-green-600">${completedCount}</span>
          <span class="text-xs text-green-500">Completed</span>
        </div>
      </div>
      <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 card-stat">
        <p class="text-xs font-bold text-slate-500 uppercase tracking-semibold mb-1">Rider Feedback Average</p>
        <div class="flex items-baseline gap-2">
          <span class="text-4xl font-extrabold text-blue-600">${feedbackAvg}★</span>
          <span class="text-xs text-blue-500">From ${db.feedbacks.length} reviews</span>
        </div>
      </div>
    </section>

    <!-- SERVER SYNC ENDPOINT INFO -->
    <div class="bg-slate-900 text-sky-400 p-5 rounded-2xl font-mono text-sm shadow-md mb-8 flex justify-between items-center gap-4 no-print flex-col md:flex-row">
      <div>
        <span class="text-emerald-400 font-bold">● CLOUD ENGINE ONLINE</span> - Dynamic API Synchronization URL:
        <div class="text-slate-200 mt-1 select-all">POST &nbsp; http://&lt;YOUR_HOST_OR_LOCAL_IP&gt;:${PORT}/sync</div>
      </div>
      <button onclick="exportToCSV()" class="bg-emerald-600 hover:bg-emerald-500 text-white font-bold font-sans px-4 py-2 rounded-lg transition text-xs shadow-sm whitespace-nowrap">
        📥 Export Shared CSV (Excel)
      </button>
    </div>

    <!-- DELIVERIES ROSTER -->
    <section class="bg-white rounded-2xl shadow-sm border border-slate-100 mb-8 overflow-hidden">
      <div class="p-6 border-b border-slate-100 flex justify-between items-center no-print flex-wrap gap-4">
        <div class="flex items-center gap-3">
          <div class="w-2.5 h-2.5 bg-blue-600 rounded-full animate-ping"></div>
          <h2 class="text-lg font-bold text-slate-900">Active Deliveries Roster</h2>
        </div>
        <button onclick="resetSharedDatabase()" class="bg-rose-50 hover:bg-rose-100 text-rose-700 hover:text-rose-800 font-bold px-4 py-2 rounded-xl transition text-xs border border-rose-100">
          ⚠️ Factory Reset Server DB
        </button>
      </div>
      <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse" id="deliveries-data-table">
          <thead>
            <tr class="bg-slate-50 border-b border-slate-100 text-slate-600 font-semibold text-xs uppercase">
              <th class="p-4">Order ID</th>
              <th class="p-4">Customer Details</th>
              <th class="p-4">Bicycle / Cycle Model</th>
              <th class="p-4">Assigned Personnel</th>
              <th class="p-4">Delivery Status</th>
              <th class="p-4">Method</th>
              <th class="p-4">Proof Photo</th>
              <th class="p-4 no-print text-right">Actions</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-100 text-sm">
            ${db.deliveries.length === 0 ? `<tr><td colspan="8" class="p-8 text-center text-slate-400">No active deliveries synchronized yet. Open your administrator app to map records!</td></tr>` : 
              db.deliveries.map(d => `
                <tr class="hover:bg-slate-50">
                  <td class="p-4 font-bold text-slate-900">${d.orderId}</td>
                  <td class="p-4">
                    <div class="font-semibold text-slate-800">${d.customerName}</div>
                    <div class="text-xs text-slate-500">${d.phoneNumber}</div>
                    <div class="text-xs text-slate-400 mt-0.5 truncate max-w-xs" title="${d.address}">${d.address}</div>
                  </td>
                  <td class="p-4 font-medium text-slate-700">${d.cycleModel}</td>
                  <td class="p-4">
                    ${d.staffName ? `<span class="bg-blue-50 text-blue-700 px-2.5 py-1 rounded-full text-xs font-semibold">${d.staffName}</span>` : `<span class="text-rose-500 font-bold text-xs uppercase bg-rose-50 px-2.5 py-1 rounded-full">Not Assigned</span>`}
                  </td>
                  <td class="p-4">
                    <span class="inline-block px-2.5 py-1 rounded-full text-xs font-bold leading-none uppercase ${
                      d.deliveryStatus === 'Delivered' 
                        ? 'bg-emerald-100 text-emerald-800' 
                        : (d.deliveryStatus === 'Booking' || d.deliveryStatus === 'Booked') 
                        ? 'bg-amber-100 text-amber-800' 
                        : 'bg-indigo-100 text-indigo-800'
                    }">
                      ${d.deliveryStatus}
                    </span>
                  </td>
                  <td class="p-4 text-slate-600 font-medium">${d.deliveryMethod}</td>
                  <td class="p-4">
                    ${d.photoUri 
                      ? `<a href="${d.photoUri}" target="_blank" class="text-sky-600 hover:underline font-bold text-xs flex items-center gap-1">🖼️ View (TAP)</a>` 
                      : `<span class="text-slate-400 text-xs">No Proof Uploaded</span>`
                    }
                  </td>
                  <td class="p-4 no-print text-right">
                    <button onclick="deleteDelivery('${d.orderId}')" class="bg-rose-50 hover:bg-rose-100 text-rose-600 hover:text-rose-700 font-bold px-3 py-1.5 rounded-lg transition text-xs border border-rose-100">
                      🗑️ Delete
                    </button>
                  </td>
                </tr>
              `).join('')
            }
          </tbody>
        </table>
      </div>
    </section>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8 no-print">
      
      <!-- STAFF ROSTER -->
      <section class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div class="p-6 border-b border-slate-100">
          <h2 class="text-base font-bold text-slate-900">Rider & Courier roster</h2>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead class="bg-slate-50 text-slate-500 text-xs uppercase">
              <tr>
                <th class="p-4">Full Name</th>
                <th class="p-4">Phone Number</th>
                <th class="p-4">Working Status</th>
                <th class="p-4 no-print text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              ${db.staff.map(s => `
                <tr class="hover:bg-slate-50">
                  <td class="p-4 font-bold text-slate-800">${s.name}</td>
                  <td class="p-4 text-slate-600">${s.phone}</td>
                  <td class="p-4">
                    <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                      ${s.status}
                    </span>
                  </td>
                  <td class="p-4 no-print text-right">
                    <button onclick="deleteStaff('${s.name}')" class="bg-rose-50 hover:bg-rose-100 text-rose-600 hover:text-rose-700 font-bold px-2.5 py-1.5 rounded-lg transition text-xs border border-rose-100">
                      🗑️ Delete
                    </button>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </section>

      <!-- ADMINS REGISTERED -->
      <section class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div class="p-6 border-b border-slate-100">
          <h2 class="text-base font-bold text-slate-900">Authorized Operator Accounts</h2>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead class="bg-slate-50 text-slate-500 text-xs uppercase">
              <tr>
                <th class="p-4">Administrator Name</th>
                <th class="p-4">Username ID</th>
                <th class="p-4">Access Level</th>
                <th class="p-4 no-print text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              ${db.admins.map(a => `
                <tr class="hover:bg-slate-50">
                  <td class="p-4 font-bold text-slate-800">${a.fullName}</td>
                  <td class="p-4 text-slate-600">${a.username}</td>
                  <td class="p-4">
                    <span class="px-2 py-0.5 rounded-full text-xs font-bold ${a.isSuperAdmin ? 'bg-orange-100 text-orange-800' : 'bg-slate-100 text-slate-800'}">
                      ${a.isSuperAdmin ? 'SUPER ADMIN' : 'ADMIN'}
                    </span>
                  </td>
                  <td class="p-4 no-print text-right">
                    ${a.username.toLowerCase() === 'gopal' || a.username.toLowerCase() === 'staff1' ? `<span class="text-xs text-slate-400 font-semibold">System</span>` : `
                      <button onclick="deleteAdmin('${a.username}')" class="bg-rose-50 hover:bg-rose-100 text-rose-600 hover:text-rose-700 font-bold px-2.5 py-1.5 rounded-lg transition text-xs border border-rose-100">
                        🗑️ Delete
                      </button>
                    `}
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </section>

    </div>

    <!-- RECENT AUDIT TRAIL LOGS -->
    <section class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
      <div class="p-6 border-b border-slate-100 flex justify-between items-center">
        <h2 class="text-base font-bold text-slate-900">System Activity Audit Log</h2>
        <span class="text-xs text-slate-400">Chronological Logs (Latest first)</span>
      </div>
      <div class="overflow-x-auto">
        <table class="w-full text-left text-sm">
          <thead class="bg-slate-50 text-slate-500 text-xs uppercase">
            <tr>
              <th class="p-4">Timestamp (UTC)</th>
              <th class="p-4">Log Event/Action</th>
              <th class="p-4">Operator</th>
              <th class="p-4">JSON Transaction Details</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-100 font-mono text-xs">
            ${db.audit_logs.length === 0 ? `<tr><td colspan="4" class="p-6 text-center text-slate-400">No activity logs recorded.</td></tr>` : 
              [...db.audit_logs].reverse().slice(0, 30).map(log => `
                <tr class="hover:bg-slate-50">
                  <td class="p-4 text-slate-500 whitespace-nowrap">${new Date(log.timestamp).toISOString().replace('T', ' ').substring(0, 19)}</td>
                  <td class="p-4">
                    <span class="px-2 py-0.5 rounded font-bold uppercase text-[10px] ${
                      log.action.includes('SUCCESS') || log.action.includes('START')
                        ? 'bg-emerald-50 text-emerald-700'
                        : log.action.includes('FAILURE') || log.action.includes('RESET')
                        ? 'bg-rose-50 text-rose-700'
                        : 'bg-blue-50 text-blue-700'
                    }">${log.action}</span>
                  </td>
                  <td class="p-4 font-bold text-slate-700">${log.username}</td>
                  <td class="p-4 text-slate-600 font-sans text-xs">${log.details || ''}</td>
                </tr>
              `).join('')
            }
          </tbody>
        </table>
      </div>
    </section>

  </main>

  <footer class="max-w-7xl mx-auto text-center py-12 text-slate-400 text-xs border-t border-slate-200 mt-16 no-print">
    <p>© 2026 Decathlon Cloud Mobility Delivery - All system transactions cryptographically verified & hashed</p>
  </footer>

  <script>
    function deleteDelivery(orderId) {
      if (confirm("Are you sure you want to delete delivery sequence " + orderId + "?")) {
        fetch('/api/delete/delivery', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ orderId })
        })
        .then(res => res.json())
        .then(data => {
          if (data.error) {
            alert("Error: " + data.error);
          } else {
            location.reload();
          }
        })
        .catch(err => alert("Connection error: " + err.message));
      }
    }

    function deleteStaff(name) {
      if (confirm("Are you sure you want to delete rider " + name + " from the roster?")) {
        fetch('/api/delete/staff', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name })
        })
        .then(res => res.json())
        .then(data => {
          if (data.error) {
            alert("Error: " + data.error);
          } else {
            location.reload();
          }
        })
        .catch(err => alert("Connection error: " + err.message));
      }
    }

    function deleteAdmin(username) {
      if (confirm("Are you sure you want to delete administrator account: " + username + "?")) {
        fetch('/api/delete/admin', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username })
        })
        .then(res => res.json())
        .then(data => {
          if (data.error) {
            alert("Error: " + data.error);
          } else {
            location.reload();
          }
        })
        .catch(err => alert("Connection error: " + err.message));
      }
    }

    function resetSharedDatabase() {
      if (confirm("Are you sure you want to COMPLETELY reset the database? This action is irreversible, and will delete all synced deliveries/staff/feedback!")) {
        const username = prompt("Please provide your authorization username (Super Admin):");
        const password = prompt("Please provide your verification key password:");
        if (!username || !password) return;

        // Perform authentication + reset
        fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password })
        })
        .then(response => {
          if (!response.ok) {
            throw new Error("Invalid username/password authorization credentials provided!");
          }
          return response.json();
        })
        .then(data => {
          const token = data.token;
          return fetch('/api/reset', {
            method: 'POST',
            headers: { 
              'Content-Type': 'application/json',
              'Authorization': 'Bearer ' + token
            }
          });
        })
        .then(response => {
          if (!response.ok) {
            throw new Error("Reset authorization forbidden! Access level Super Admin is required.");
          }
          alert("Database factory reset completed successfully!");
          location.reload();
        })
        .catch(err => {
          alert("Error: " + err.message);
        });
      }
    }

    function exportToCSV() {
      let csv = "Order ID,Customer Name,Phone,Bicycle Model,Delivery Method,Status\\n";
      const rows = document.querySelectorAll("#deliveries-data-table tbody tr");
      
      rows.forEach(row => {
        const cols = row.querySelectorAll("td");
        if (cols.length >= 6) {
          const orderId = cols[0].innerText.trim();
          const nameEmail = cols[1].querySelector("div:nth-child(1)") ? cols[1].querySelector("div:nth-child(1)").innerText.trim() : "";
          const phone = cols[1].querySelector(".text-xs") ? cols[1].querySelector(".text-xs").innerText.trim() : "";
          const model = cols[2].innerText.trim();
          const status = cols[4].innerText.trim();
          const method = cols[5].innerText.trim();
          csv += '"' + orderId + '","' + nameEmail + '","' + phone + '","' + model + '","' + method + '","' + status + '"\\n';
        }
      });

      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement("a");
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "decathlon_deliveries_report_" + Date.now() + ".csv");
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  </script>
</body>
</html>`;
  res.send(html);
});

// Boot the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`====================================================`);
  console.log(` Decathlon Cloud Production API running on port ${PORT}`);
  console.log(` Sync endpoint active: http://localhost:${PORT}/sync`);
  console.log(` Management Dashboard: http://localhost:${PORT}/`);
  console.log(`====================================================`);
});
